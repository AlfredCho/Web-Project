package com.wmc.algorithm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/algorithm/editquestionok.do")
public class EditQuestionOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//EditQuestionOk.java
		
		req.setCharacterEncoding("UTF-8");
		
		String seq = req.getParameter("seq");
		String questionName = req.getParameter("questionName");
		String questionContent = req.getParameter("questionContent");
		String input = req.getParameter("input");
		String output = req.getParameter("output");
		String ex = req.getParameter("ex");
		
		QuestionDAO dao = new QuestionDAO();
		QuestionDTO dto = new QuestionDTO();
		
		dto.setSeq(seq);
		dto.setQuestionName(questionName);
		dto.setQuestionContent(questionContent);
		dto.setInput(input);
		dto.setOutput(output);
		dto.setEx(ex);
		
		int result = dao.edit(dto);
		
		req.setAttribute("seq", seq);
		req.setAttribute("result", result);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/editquestionok.jsp");
		dispatcher.forward(req, resp);

	}

}