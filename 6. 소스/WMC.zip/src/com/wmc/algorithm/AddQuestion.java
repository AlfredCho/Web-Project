package com.wmc.algorithm;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/algorithm/addquestion.do")
public class AddQuestion extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//AddQuestion.java
		
		String active = req.getParameter("active");
		if (active == null || active.equals("")) active = "2";
		
//		QuestionDAO dao = new QuestionDAO();
//		
//		int max = dao.searchMax();

		req.setAttribute("active", active);
//		req.setAttribute("max", max);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/algorithm/addquestion.jsp");
		dispatcher.forward(req, resp);

	}

}
