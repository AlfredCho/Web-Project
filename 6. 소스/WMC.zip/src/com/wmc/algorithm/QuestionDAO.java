package com.wmc.algorithm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;

public class QuestionDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	
	public QuestionDAO() {
		
		DBUtil util = new DBUtil();
		conn = util.connect();
		
	}



	public int addQuestion(QuestionDTO dto) {
		
		try {

			String sql = "insert into tblQuestion (seq,id,questionName,questionContent,input,output,ex,sourceId,clsfc,language,status)"
						+"values(question_seq.nextval,?,?,?,?,?,?,?,0,1,default)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getId());
			stat.setString(2, dto.getQuestionName());
			stat.setString(3, dto.getQuestionContent());
			stat.setString(4, dto.getInput());
			stat.setString(5, dto.getOutput());
			stat.setString(6, dto.getEx());
			stat.setString(7, dto.getSourceId());
			//System.out.println(stat.executeUpdate());
			return stat.executeUpdate();
			

		} catch (Exception e) {
			System.out.println("QuestionDAO.addQuestion : " + e.toString());
		}

		return 0;
	}





	public String getSeq() {

		try {

			String sql = "select max(seq)as maxseq from tblQuestion";

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if(rs.next()) {
				return rs.getString("maxseq");
			}
			
		} catch (Exception e) {
			System.out.println("QuestionDAO.getSeq : " + e.toString());
		}

		return null;
	}



	public QuestionDTO get(String seq) {
		
		try {

			String sql = "select * from tblQuestion where seq =?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			rs = stat.executeQuery();
			
			QuestionDTO dto = new QuestionDTO();
			
			if(rs.next()) {
				dto.setSeq(rs.getString("seq"));
				dto.setId(rs.getString("id"));
				dto.setQuestionName(rs.getString("questionName"));
				dto.setQuestionContent(rs.getString("questionContent"));
				dto.setInput(rs.getString("input"));
				dto.setOutput(rs.getString("output"));
				dto.setEx(rs.getString("ex"));
				dto.setSourceId(rs.getString("sourceId"));
				dto.setClsfc(rs.getString("clsfc"));
				dto.setLanguage(rs.getString("language"));
				dto.setStatus(rs.getString("status"));
				
				return dto;
			}

		} catch (Exception e) {
			System.out.println("QuestionDAO.get : " + e.toString());
		}

		return null;
	}



	public int addSubmit(SubmitDTO dto) {

		try {

			String sql = "insert into tblSubmission (seq, questionNum, id, languageType, submitCode, regdate, result,status)" + 
					      "values(submission_seq.nextval, ?,?,?,?,sysdate,1,default)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getQuestionNum());
			stat.setString(2, dto.getId());
			stat.setString(3, dto.getLanguageType());
			stat.setString(4, dto.getSubmitCode());
			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			System.out.println("QuestionDAO.addSubmit : " + e.toString());
		}

		return 0;
	}



	public ArrayList<QuestionListDTO> list(HashMap<String, String> map) {

		try {
			
			String where = "";
			if(map.get("isSearch").equals("true")) {
				
				where= String.format("where %s like '%%%s%%'"
									, map.get("column")
									, map.get("word"));
				
				
			}
	
			/*
			 * String sql =
			 * String.format("select * from joinquestion %s order by rnum desc", where);
			 */
	
			String sql = String.format("select * from (select a.*, rownum as rnum2 from (select * from joinquestion %s order by rnum desc) a) where rnum2 between %s and %s"
					, where
					, map.get("begin")
					, map.get("end")
					);
			
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			ArrayList<QuestionListDTO> list = new ArrayList<QuestionListDTO>();
			
			while (rs.next()) {
				
				QuestionListDTO ldto = new QuestionListDTO();
				
				ldto.setRnum(rs.getString("rnum"));
				ldto.setSeq(rs.getString("seq"));
				//ldto.setQuestionNum(rs.getString("questionNum"));
				ldto.setQuestionName(rs.getString("questionName"));
				ldto.setSourceId(rs.getString("sourceId"));
				ldto.setLanguage(rs.getString("language"));
				ldto.setTotalCnt(rs.getString("totalCnt"));
				ldto.setCorrect(rs.getString("correct"));
				ldto.setPer(rs.getString("per"));
				
				list.add(ldto);
				
			}
			return list;
			
			
		} catch (Exception e) {
			System.out.println("QuestionDAO.list : " + e.toString());
		}

		return null;
	}

	public QuestionListDTO viewBar(String seq) {
		
		try {

			//String sql = "select * from vwjoinquestion where seq = ?";
			String sql = "select * from joinquestion where seq = ? order by rnum desc";
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			rs = stat.executeQuery();
			
			QuestionListDTO vdto = new QuestionListDTO();
			if(rs.next()) {
				
				vdto.setRnum(rs.getString("rnum"));
				vdto.setSeq(rs.getString("seq"));
				vdto.setTotalCnt(rs.getString("totalCnt"));
				vdto.setCorrect(rs.getString("correct"));
				vdto.setPer(rs.getString("per"));
				
				return vdto;
			}
			
			
			
		} catch (Exception e) {
			System.out.println("QuestionDAO.viewBar : " + e.toString());
		}

		
		return null;
	}



	public int getTotalCount(HashMap<String, String> map) {

		try {

			String where = "";
			
			if(map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'"
										, map.get("column")
										, map.get("word"));
			}
	
			String sql = String.format("select count(*) as cnt from vwjoinquestion %s", where);

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if(rs.next()) {
				
				return rs.getInt("cnt");
			}
		
		
		} catch (Exception e) {
			System.out.println("QuestionDAO.getTotalCount : " + e.toString());
		}

		return 0;
	}



	public int edit(QuestionDTO dto) {
		
		try {

			String sql = "update tblquestion set questionName = ?, questionContent = ?, input = ?, output = ?, ex = ? where seq = ?";

			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getQuestionName());
			stat.setString(2, dto.getQuestionContent());
			stat.setString(3, dto.getInput());
			stat.setString(4, dto.getOutput());
			stat.setString(5, dto.getEx());
			stat.setString(6, dto.getSeq());
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			System.out.println("QuestionDAO.edit : " + e.toString());
		}

		return 0;
	}



	public int delQuestion(String seq) {

		try {

			String sql = "delete from tblQuestion where seq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("QuestionDAO.delQuestion : " + e.toString());
		}

		return 0;
	}



	









}



