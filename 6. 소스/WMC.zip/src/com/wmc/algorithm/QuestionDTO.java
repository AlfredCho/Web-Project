package com.wmc.algorithm;

public class QuestionDTO {

	private String seq;       //문제번호
	private String id;        //로그인 아이디
	private String questionName;    //문제이름
	private String questionContent; //문제 내용
	private String input;     //입력란
	private String output;	  //출력란
	private String ex;        //예제
	private String sourceId;  //제출한 사람아이디
	private String clsfc;     //분류
	private String language;  //다국어지원
	private String status;
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQuestionName() {
		return questionName;
	}
	public void setQuestionName(String questionName) {
		this.questionName = questionName;
	}
	public String getInput() {
		return input;
	}
	public void setInput(String input) {
		this.input = input;
	}
	public String getEx() {
		return ex;
	}
	public void setEx(String ex) {
		this.ex = ex;
	}
	public String getSourceId() {
		return sourceId;
	}
	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}
	public String getClsfc() {
		return clsfc;
	}
	public void setClsfc(String clsfc) {
		this.clsfc = clsfc;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getQuestionContent() {
		return questionContent;
	}
	public void setQuestionContent(String questionContent) {
		this.questionContent = questionContent;
	}
	public String getOutput() {
		return output;
	}
	public void setOutput(String output) {
		this.output = output;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
