package com.wmc.project;

public class VwModProgressDTO {

	private String proSeq;
	private String id;
	private String name;
	private int taskDone;
	private int totalTask;
	private String modProgress;
	
	public String getModProgress() {
		return modProgress;
	}
	public void setModProgress(String modProgress) {
		this.modProgress = modProgress;
	}
	public String getProSeq() {
		return proSeq;
	}
	public void setProSeq(String proSeq) {
		this.proSeq = proSeq;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getTaskDone() {
		return taskDone;
	}
	public void setTaskDone(int taskDone) {
		this.taskDone = taskDone;
	}
	public int getTotalTask() {
		return totalTask;
	}
	public void setTotalTask(int totalTask) {
		this.totalTask = totalTask;
	}
	
	
	
}
