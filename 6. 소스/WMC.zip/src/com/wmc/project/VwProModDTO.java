package com.wmc.project;

public class VwProModDTO {

	private String proSeq;
	private String projectName;
	private String projectNote;
	private String proProgress;
	private String sDate;
	private String eDate;
	private String id;
	private String name;
	
	private String modSeq;
	private String modName;
	private String modProgress;
	private String projectLeader;
	
	private int taskDone;
	private int totalTask;
	
	
	public int getTaskDone() {
		return taskDone;
	}
	public void setTaskDone(int taskDone) {
		this.taskDone = taskDone;
	}
	public int getTotalTask() {
		return totalTask;
	}
	public void setTotalTask(int totalTask) {
		this.totalTask = totalTask;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProjectLeader() {
		return projectLeader;
	}
	public void setProjectLeader(String projectLeader) {
		this.projectLeader = projectLeader;
	}
	public String getProSeq() {
		return proSeq;
	}
	public void setProSeq(String proSeq) {
		this.proSeq = proSeq;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectNote() {
		return projectNote;
	}
	public void setProjectNote(String projectNote) {
		this.projectNote = projectNote;
	}
	public String getProProgress() {
		return proProgress;
	}
	public void setProProgress(String proProgress) {
		this.proProgress = proProgress;
	}
	public String getsDate() {
		return sDate;
	}
	public void setsDate(String sDate) {
		this.sDate = sDate;
	}
	public String geteDate() {
		return eDate;
	}
	public void seteDate(String eDate) {
		this.eDate = eDate;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getModSeq() {
		return modSeq;
	}
	public void setModSeq(String modSeq) {
		this.modSeq = modSeq;
	}
	public String getModName() {
		return modName;
	}
	public void setModName(String modName) {
		this.modName = modName;
	}
	public String getModProgress() {
		return modProgress;
	}
	public void setModProgress(String modProgress) {
		this.modProgress = modProgress;
	}
	
	
	
	
}
