package com.wmc.project;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/project/view.do")
public class View extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		
		req.setCharacterEncoding("utf-8");
		
		HttpSession session = req.getSession();
		String id = session.getAttribute("certification").toString();
		
		
		// 클릭한 프로젝트 진행률
		String seq = req.getParameter("seq");
		
		if (req.getParameter("seq") == null) {
			seq = req.getParameter("proSeq");
		}
		
		ProjectDAO dao = new ProjectDAO();
		
		
		
		// 탈퇴한 회원인지 검사
		
		// 회원 등급 검사
		String lv = dao.getLv(id, seq);
		
		boolean exist = dao.exist(id, seq);
		
		if (exist) {
			
			// view 페이지로 넘겨 줘야 하는 데이터
			/*
			 * 그 프로젝트의 멤버 + 담당 모듈 + 진행률
			 * 해당 프로젝트의 내 모듈 dto
			 * */
			
			
			// 프로젝트 기본 정보
			ProjectDTO projectDto = dao.getProject(seq);
			
			// 한 프로젝트의 멤버와 각자의 진행률 정보
			
			ArrayList<VwCountTaskDTO> myTeamInfo = dao.getCountTask(seq);
			
			for (VwCountTaskDTO dto : myTeamInfo) {
				double rate = 0;
				int taskDone = dto.getTaskDone();
				int totalTask = dto.getTotalTask();
				
				if (totalTask != 0) {
					rate = ((double)taskDone / totalTask) * 100;
				}
				dto.setModProgress(rate);
			}
			
			// 나의 업무
			ArrayList<VwMyTasksDTO> myTasks = dao.getMyTasks(id, seq);
			
			// 프로젝트 진행률 계산을 위한 정보
			VwCountTask2DTO cDto = dao.getProProgress(seq);
			
			// 프로젝트 진행률 계산
			
			
			double rate = 0;
			
			int taskDone = cDto.getTaskDone();
			int totalTask = cDto.getTotalTask();
			
			if (totalTask != 0) {
				rate = ((double)taskDone / totalTask) * 100;
			}
			
			req.setAttribute("id", id);
			req.setAttribute("seq", seq); // 프로젝트 번호
			req.setAttribute("lv", lv); // 팀장여부
			req.setAttribute("projectDto", projectDto);
			req.setAttribute("myTeamInfo", myTeamInfo);
			req.setAttribute("myTasks", myTasks);
			req.setAttribute("proProgress", rate);
			
			RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/view.jsp");
			dispatcher.forward(req, resp);
		} else {
			// 쫓아내기
			
			resp.setCharacterEncoding("utf-8");
			PrintWriter writer = resp.getWriter();
			
			writer.println("<html>");
			writer.println("<meta charset ='utf-8'>");
			writer.println("<body>");
			writer.println("<script>");
			writer.println("alert('유효하지 않은 접근입니다.')");
			writer.println("location.href='/WMC/project/list.do'");
			writer.println("</script>");
			writer.println("</body>");
			writer.println("</html>");
			
			writer.close();
		}
		
	}
}