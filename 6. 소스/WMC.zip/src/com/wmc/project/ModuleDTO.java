package com.wmc.project;

public class ModuleDTO {

	private String seq;
	private String proSeq;
	private String moduleTaker;
	private String name;
	private String progress;
	private String exist;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getProSeq() {
		return proSeq;
	}
	public void setProSeq(String proSeq) {
		this.proSeq = proSeq;
	}
	public String getModuleTaker() {
		return moduleTaker;
	}
	public void setModuleTaker(String moduleTaker) {
		this.moduleTaker = moduleTaker;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
	public String getExist() {
		return exist;
	}
	public void setExist(String exist) {
		this.exist = exist;
	}
	
	
}
