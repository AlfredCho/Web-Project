package com.wmc.project;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/project/addtask.do")
public class AddTask extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");
		
		String proSeq = req.getParameter("proSeq");
		String id = req.getParameter("id");
		
		// 기능 select에 옵션으로 넣을 해당 프로젝트의 기능명 
		ProjectDAO dao = new ProjectDAO();
		ArrayList<VwProModDTO> list = dao.getProMod(proSeq);
		
		req.setAttribute("proSeq", proSeq);
		req.setAttribute("id", id);
		req.setAttribute("name", "박보영");
		req.setAttribute("list", list);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/addtask.jsp");
		dispatcher.forward(req, resp);
	}
}
