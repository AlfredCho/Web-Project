package com.wmc.project;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/project/del.do")
public class Del extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("aa");
		String seq = req.getParameter("seq");
		String id = req.getParameter("id");
		
		ProjectDAO dao = new ProjectDAO();
		
		// 멤버 탈퇴
		int result = dao.del(seq, id);
		System.out.println(result);
		resp.setContentType("application/json");
		
		PrintWriter writer = resp.getWriter();
		writer.print("{");
		writer.printf("\"result\":\"%d\"", result);
		writer.print("}");
		writer.close();
		
	}
}




















