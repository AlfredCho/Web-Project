package com.wmc.project;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.member.MemberDTO;

@WebServlet("/project/adddata.do")
public class AddData extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		
		ProjectDAO dao = new ProjectDAO();

		String search = req.getParameter("search");
		
		if (search != null && !search.equals("")) {
				
			String keyword = req.getParameter("keyword");
			ArrayList<MemberDTO> searchResult = dao.getSearchResult(keyword);

			resp.setCharacterEncoding("utf-8");
			resp.setContentType("application/json");
			
			
			/*
			[
				{
					"name" : "장도연",
					"id" : "doyeon"
				},
				
				{
					"name" : "장도연",
					"id" : "doyeon"
				}
			]
			*/
			
			PrintWriter writer = resp.getWriter();

			writer.print("[");
			for (int i=0; i<searchResult.size(); i++) {
				writer.print("{");
				
				writer.printf("\"name\" : \"%s\",", searchResult.get(i).getName());
				writer.printf("\"id\" : \"%s\"", searchResult.get(i).getId());
				
				writer.print("}");
				if (i != searchResult.size()-1) writer.print(",");
			}
			writer.print("]");
			writer.close();
			
					
		}
		
	}
}























