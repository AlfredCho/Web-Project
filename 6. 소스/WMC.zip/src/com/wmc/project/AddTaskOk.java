package com.wmc.project;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/project/addtaskok.do")
public class AddTaskOk extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");
		String proSeq = req.getParameter("proSeq");
		String modSeq = req.getParameter("modSeq");
		String priority = req.getParameter("priority");
		String name = req.getParameter("name");
		String status = req.getParameter("status");
		String taskTaker = req.getParameter("taskTaker");
		
		TaskDTO dto = new TaskDTO();
		dto.setName(name);
		dto.setPriority(priority);
		dto.setStatus(status);
		dto.setTaskTaker(taskTaker);
		
		ProjectDAO dao = new ProjectDAO();
		int result = dao.addTask(dto, Integer.parseInt(modSeq));
		
		req.setAttribute("result", result);
		req.setAttribute("proSeq", proSeq);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/addtaskok.jsp");
		dispatcher.forward(req, resp);
	}
}
