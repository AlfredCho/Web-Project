package com.wmc.project;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.TreeMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/project/addok.do")
public class AddOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		req.setCharacterEncoding("utf-8");

		// 넘어온 데이터 맵
		Map<String, String[]> map = req.getParameterMap();
		Iterator<String> keys = map.keySet().iterator();

		// project
		ProjectDTO projectDto = new ProjectDTO();

		// members
		ArrayList<String> members = new ArrayList<String>();
		
		// leader
		String leader = "";

		// moduleName
		Map<String, String> moduleName = new HashMap<String, String>();

		// moduleTaker
		Map<String, String> moduleTaker = new HashMap<String, String>();

		// taskPriority
		Map<String, String> taskPriority = new HashMap<String, String>();

		// taskName
		Map<String, String> taskName = new HashMap<String, String>();

		// taskStatus

		Map<String, String> taskStatus = new HashMap<String, String>();

//		// taskTaker
//		Map<String, String> taskTaker = new HashMap<String, String>();
		
		while (keys.hasNext()) {
			String key = keys.next();

			
			  System.out.println("key: " + key); for (String value: map.get(key)) {
			  System.out.print("value: "); System.out.print(value + ", "); }
			  System.out.println();
			 
			  
			if (key.indexOf("project") > -1) {

				if (key.equals("projectName")) projectDto.setName(map.get(key)[0]);
				if (key.equals("projectNote")) projectDto.setNote(map.get(key)[0]);
				if (key.equals("projectStartDate")) projectDto.setsDate(map.get(key)[0]);
				if (key.equals("projectEndDate")) projectDto.seteDate(map.get(key)[0]);
				if (key.equals("projectLeader")) leader = map.get(key)[0];
				
			}

			else if (key.indexOf("member") > -1) members.add(map.get(key)[0]);

			else if (key.indexOf("moduleName") > -1) moduleName.put(key, map.get(key)[0]);

			else if (key.indexOf("moduleTaker") > -1) moduleTaker.put(key, map.get(key)[0]);

			else if (key.indexOf("taskPriority") > -1) taskPriority.put(key, map.get(key)[0]);

			else if (key.indexOf("taskname") > -1) taskName.put(key, map.get(key)[0]);

			else if (key.indexOf("taskStatus") > -1) {

				// check가 풀려 있을 때는 아예 parameter가 없음
				taskStatus.put(key, map.get(key)[0]);
			}
			
//			else if (key.indexOf("taskStatus") > -1) taskTaker.put(key, map.get(key)[0]);
		}
		// 출력
		//-----------------------------------------------------------------------------------------------------------------

		//System.out.println("멤버");
		for (int i = 0; i < members.size(); i++)
			System.out.println(members.get(i));

		//System.out.println();

		//System.out.println("모듈네임");
		Iterator<String> moduleNameKeys = moduleName.keySet().iterator();
		while (moduleNameKeys.hasNext()) {
			String key = moduleNameKeys.next();
			//System.out.println("키: " + key + ", 값: " + moduleName.get(key));
		}
		//System.out.println();

		//System.out.println("모듈테이커");
		Iterator<String> moduleTakerKeys = moduleTaker.keySet().iterator();
		while (moduleTakerKeys.hasNext()) {
			String key = moduleTakerKeys.next();
			//System.out.println("키: " + key + ", 값: " + moduleTaker.get(key));
		}
		//System.out.println();

		//System.out.println("태스크프라이어리티");
		Iterator<String> taskPriorityKeys = taskPriority.keySet().iterator();
		while (taskPriorityKeys.hasNext()) {
			String key = taskPriorityKeys.next();
			//System.out.println("키: " + key + ", 값: " + taskPriority.get(key));
		}
		//System.out.println();

		//System.out.println("태스크네임");
		Iterator<String> taskNameKeys = taskName.keySet().iterator();
		while (taskNameKeys.hasNext()) {
			String key = taskNameKeys.next();
			//System.out.println("키: " + key + ", 값: " + taskName.get(key));
		}
		//System.out.println();

		//System.out.println("태스크상태");
		Iterator<String> taskStatusKeys = taskStatus.keySet().iterator();
		while (taskStatusKeys.hasNext()) {
			String key = taskStatusKeys.next();
			//System.out.println("키: " + key + ", 값: " + taskStatus.get(key));
		}
		//System.out.println();

		//-----------------------------------------------------------------------------------------------------------------

		 ProjectDAO dao = new ProjectDAO();
		 
		 // insert Project 
		 
		 int resultProject = dao.addProject(projectDto);
		 
		
		 // insert tblProjectMember; 
		 
		 int maxProject = dao.getMaxProject();
		 
		 int resultProjectMember = 1;
		 
		 for (int i=0; i<members.size(); i++) {
			 String member = members.get(i);
			 if (! member.equals(leader)) resultProjectMember *= dao.addMemeber(member, maxProject);
			 else resultProjectMember *= dao.addLeader(member, maxProject);
		 }
		 
		 // sort Module
		 
		 TreeMap<String, String> tModuleName = new TreeMap<String, String>(moduleName);
		 Iterator<String> tModuleNameKeys = tModuleName.keySet().iterator();
		 
		 TreeMap<String, String> tModuleTaker = new TreeMap<String, String>(moduleTaker);
		 Iterator<String> tModuleTakerKeys = tModuleTaker.keySet().iterator();
		 
		 // save modulenum into queue
		 
		 Queue<String> qModuleNum = new LinkedList<String>();
		 
		 qModuleNum.offer("0");
		 
		 // insert Module
		 int resultModule = 1;
		 
		 
		 for (int i=1; i<=moduleName.size(); i++) { 
			
			ModuleDTO moduleDto = new ModuleDTO();
			if (tModuleTakerKeys.hasNext()) {
				String key = tModuleTakerKeys.next();
				moduleDto.setModuleTaker(tModuleTaker.get(key));
				
				qModuleNum.offer(key.substring(11));
			}
			
			if (tModuleNameKeys.hasNext()) {
				String key = tModuleNameKeys.next();
				moduleDto.setName(tModuleName.get(key));
			}
			
			resultModule *= dao.addModule(moduleDto, maxProject); 
		 }
		 
		//-----------------------------------------------------------------------------------------------------------------
		 
		 // sort task
		  
		 TreeMap<String, String> tTaskName = new TreeMap<String, String>(taskName);
		 Iterator<String> tTaskNameKeys = tTaskName.keySet().iterator();
		 
		 TreeMap<String, String> tTaskPriority = new TreeMap<String, String>(taskPriority);
		 Iterator<String> tTaskPriorityKeys = tTaskPriority.keySet().iterator();
		 
		 TreeMap<String, String> tTaskStatus = new TreeMap<String, String>(taskStatus);
		 Iterator<String> tTaskStatusKeys = tTaskStatus.keySet().iterator();
		 
		 TreeMap<String, String> tTaskTaker = new TreeMap<String, String>(moduleTaker);
		 Iterator<String> tTaskTakerKeys = tTaskTaker.keySet().iterator();
		 
		 // get maxModule
		 
		 int maxModule = dao.getMaxModule();
		 int modSeq = maxModule - moduleName.size(); // modSeq: DB상의 modSeq 
		 // insert task
		 int resultTask = 1;
		 
		 
		 
		 String taskTaker = "";
		 for (int i=1; i<=taskName.size(); i++) {
		  
			 TaskDTO taskDto = new TaskDTO();
			  
			 // 1번 모듈에 있는 아이들 부터 다 찾아서 dto로 묶은 뒤 dao 보내기.
			 // 이미 정렬 되어 있기 때문에 차례대로 dto로 묶은 뒤 dao 보내면 됨
			 
			 String modNum = ""; // modNum: 현재 페이지의 module num
			 
			 if (tTaskNameKeys.hasNext()) {
				 String key = tTaskNameKeys.next();
				 String[] temp = key.split("_");
				 modNum = temp[0].substring(1);
				 
				 taskDto.setName(tTaskName.get(key)); 
			 }
			 
			 if (tTaskPriorityKeys.hasNext()) {
				 String key = tTaskPriorityKeys.next();
				 taskDto.setPriority(tTaskPriority.get(key));
			 }
			 
			 if (tTaskStatusKeys.hasNext()) {
				 String key = tTaskStatusKeys.next();
				 taskDto.setStatus(tTaskStatus.get(key));
			 }
			 
			 // 큐 head에 있는 모듈 넘 (ex. moduleName1 > "1")과
			 // 지금 넣고자 하는 태스크의 모듈 넘 (ex. m1_taskName6 > "1")을 비교
			 
			 if (qModuleNum.peek().equals(modNum)) {
				 
				 taskDto.setTaskTaker(taskTaker);
				 
			 } else {
				 System.out.println("poll: " + qModuleNum.poll());
				 if (tTaskTakerKeys.hasNext()) {
					 String key = tTaskTakerKeys.next();
					 taskTaker = tTaskTaker.get(key);
				 }
				 
				 taskDto.setTaskTaker(taskTaker);
				 modSeq++;
			 }
			 
//			 System.out.println(i+"번째 taskdto");
//			 System.out.println("모듈 시퀀스: " + modSeq);
//			 System.out.println(taskDto.getName());
//			 System.out.println(taskDto.getPriority());
//			 System.out.println(taskDto.getStatus());
//			 System.out.println(taskDto.getTaskTaker());
//			 System.out.println();
			 
			 
			 // set modSeq
			 
			 
			 resultTask *= dao.addTask(taskDto, modSeq);
			 
		}
		 
		 if (resultProject * resultProjectMember * resultModule * resultTask == 1) req.setAttribute("result", 1);
		 req.setAttribute("seq", maxProject);
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/project/addok.jsp");
		dispatcher.forward(req, resp);
	}
}
