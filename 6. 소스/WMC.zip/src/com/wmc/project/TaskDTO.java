package com.wmc.project;

public class TaskDTO {

	private String seq;
	private String modSeq;
	private String taskTaker;
	private String priority;
	private String name;
	private String exist;
	private String status;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getModSeq() {
		return modSeq;
	}
	public void setModSeq(String modSeq) {
		this.modSeq = modSeq;
	}
	
	
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getExist() {
		return exist;
	}
	public void setExist(String exist) {
		this.exist = exist;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTaskTaker() {
		return taskTaker;
	}
	public void setTaskTaker(String taskTaker) {
		this.taskTaker = taskTaker;
	}
	
	
}
