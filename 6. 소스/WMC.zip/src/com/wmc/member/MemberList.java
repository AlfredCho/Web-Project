package com.wmc.member;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/member/memberlist.do")
public class MemberList extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String column = req.getParameter("column");
		String word = req.getParameter("word");
		boolean isSearch = false;

		HashMap<String, String> map = new HashMap<String, String>();

		if ((column != null && word != null) && (column != "" && word != "")) {
			// 검색 요청 시
			isSearch = true;
			map.put("column", column);
			map.put("word", word);
			map.put("isSearch", "true");
		} else {
			map.put("isSearch", "false");
		}

		MemberDAO dao = new MemberDAO();

		// 페이징 관련 변수
		int nowPage = 0; // 현재 페이지 번호
		int totalCount = 0; // 총 게시물
		int pageSize = 10; // 한 페이지당 출력 게시물
		int totalPage = 0; // 총 페이지 수
		int begin = 0; // where 절
		int end = 0; // where 절
		int n = 0; // 페이지 바 제작
		int loop = 0; // 페이지 바 제작
		int blockSize = 10; // 페이지 바 제작

		String page = req.getParameter("page");

		if (page == null || page == "")
			nowPage = 1;
		else
			nowPage = Integer.parseInt(page);

		// nowPage : 현재 보게될 페이지 번호 + 연산
		// 1page - > where rnum between 1 and 10
		// 2page - > where rnum between 11 and 20
		// 3page - > where rnum between 21 and 30
		begin = ((nowPage - 1) * pageSize) + 1;
		end = begin + pageSize - 1;

		map.put("begin", begin + "");
		map.put("end", end + "");

		// 총 게시물 수
		totalCount = dao.getTotalCount(map);

		// 총 페이지 수
		totalPage = (int) Math.ceil((double) totalCount / pageSize);

		ArrayList<MemberDTO> list = dao.memberList(map);

		// 페이지 바 제작
		String pagebar = "";

		/*
		 * for (int i=1; i<=totalPage; i++) {
		 * 
		 * if (i== nowPage) { pagebar += String.
		 * format(" <a href='#' onclick='event.preventDefault();' style='color: tomato;'>%d</a>"
		 * , i); } else { pagebar +=
		 * String.format(" <a href='/myhome/board/list.do?page=%d'>%d</a>", i,i); } }
		 */

		loop = 1; // 루프변수(while)
		n = ((nowPage - 1) / blockSize) * blockSize + 1;

		/*
		 * 
		 * <nav> <ul class="pagination"> <li> <a href="#" aria-label="Previous"> <span
		 * aria-hidden="true">&laquo;</span> </a> </li> <li><a href="#">1</a></li>
		 * <li><a href="#">2</a></li> <li><a href="#">3</a></li> <li><a
		 * href="#">4</a></li> <li><a href="#">5</a></li> <li> <a href="#"
		 * aria-label="Next"> <span aria-hidden="true">&raquo;</span> </a> </li> </ul>
		 * </nav>
		 * 
		 */

		pagebar += "<nav>\r\n" + "  <ul class='pagination pagination-sm'>";

		// 이전 10페이지
		/*
		 * if (n == 1) { pagebar += String.
		 * format(" <a href='#' onclick='event.preventDefault();'>[이전 %d 페이지]</a>",
		 * blockSize); } else { pagebar +=
		 * String.format(" <a href='/myhome/board/list.do?page=%d'>[이전 %d 페이지]</a>",
		 * n-1, blockSize); }
		 */
		if (n == 1) {
			pagebar += String.format(" <li>" + "      <a href='#' aria-label='Previous'>"
					+ "        <span aria-hidden='true'>&laquo;</span>" + "      </a>" + "    </li>");
		} else {
			pagebar += String
					.format("  <li>" + "      <a href='/wmc/member/memberlist.do?page=%d' aria-label='Previous'>"
							+ "        <span aria-hidden='true'>&laquo;</span>" + "      </a>" + "    </li>", n - 1);
		}

		// 페이지 번호 루프
		/*
		 * while (!(loop > blockSize || n > totalPage)) { if (n== nowPage) { pagebar +=
		 * String.
		 * format(" <a href='#' onclick='event.preventDefault();' style='color: tomato;'>%d</a>"
		 * , n); } else { pagebar +=
		 * String.format(" <a href='/myhome/board/list.do?page=%d'>%d</a>", n,n); }
		 * loop++; n++; }
		 */
		
			while (!(loop > blockSize || n > totalPage)) {
				
				if (n == nowPage) {
					pagebar += String.format("<li class='active'><a href='#'>%d</a></li>", n);
				} else {
					
					if (isSearch) {
						pagebar += String.format(
								" <li><a href='/wmc/member/memberlist.do?page=%d&column=%s&word=%s'>%d</a></li>", n, column,
								word, n);
					} else {
						pagebar += String.format(
								" <li><a href='/wmc/member/memberlist.do?page=%d'>%d</a></li>", n, n);
					}
					
				}
				loop++;
				n++;
			
		} 

			// 다음 10페이지
			/*
			 * if (n > totalPage) { pagebar += String.
			 * format(" <a href='#' onclick='event.preventDefault();'>[다음 %d 페이지]</a>",
			 * blockSize); } else { pagebar +=
			 * String.format(" <a href='/myhome/board/list.do?page=%d'>[다음 %d 페이지]</a>", n,
			 * blockSize); }
			 */
			if (n > totalPage) {
				pagebar += String.format(" <li>" + "      <a href='#' aria-label='Next'>"
						+ "        <span aria-hidden='true'>&raquo;</span>" + "      </a>" + "    </li>");
			} else {
				pagebar += String
						.format(" <li>" + "      <a href='/wmc/member/memberlist.do?page=%d' aria-label='Next'>"
								+ "        <span aria-hidden='true'>&raquo;</span>" + "      </a>" + "    </li>", n);
			}

			pagebar += "</ul>\r\n" + "</nav>";

			/*
			 * if (isSearch) { ArrayList<MemberDTO> slist = dao.searchedMember(map);
			 * req.setAttribute("slist", slist); System.out.println("slist:" +
			 * slist.size()); }
			 */

			req.setAttribute("pagebar", pagebar);
			req.setAttribute("totalCount", totalCount);
			req.setAttribute("totalPage", totalPage);
			req.setAttribute("nowPage", nowPage);

			req.setAttribute("isSearch", isSearch);
			req.setAttribute("column", column);
			req.setAttribute("word", word);

			req.setAttribute("list", list);

			RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/member/memberlist.jsp");
			dispatcher.forward(req, resp);
		}

	
}