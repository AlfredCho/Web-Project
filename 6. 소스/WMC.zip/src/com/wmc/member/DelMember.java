package com.wmc.member;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

@WebServlet("/member/delmember.do")
public class DelMember extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//관리자 -> 회원 탈퇴시키기
		String id = req.getParameter("id");
		
		MemberDTO dto = new MemberDTO();
		
		dto.setId(id);
		
		StudyDAO recruitdao = new StudyDAO();
		recruitdao.delrecruitStudy(id); // 탈퇴하는 아이디로 모집공고 작성되어있을시 삭제
		recruitdao.delrecruitStudyGroup(id); // 스터디 그룹 탈퇴
		
		MemberDAO dao = new MemberDAO();
		
		int result = dao.delMember(dto); // 멤버 테이블에서 del을 0으로 만들기
		
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");
		
		PrintWriter writer = resp.getWriter();

		writer.print("{");
		writer.printf("\"result\":\"%d\"", result);
		writer.print("}");

		writer.close();

		
	}

}