package com.wmc.member;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/member/loginok.do")
public class LoginOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		
		String id = req.getParameter("id");
		String pw = req.getParameter("pw");
		
		MemberDTO dto = new MemberDTO();
		
		dto.setId(id);
		dto.setPw(pw);
		
		MemberDAO dao = new MemberDAO();
		
		MemberDTO result = dao.login(dto);
		
		if (result != null) {
			String byear = result.getBirth().substring(0, 4);
			String bmonth = result.getBirth().substring(5, 7);
			String bday = result.getBirth().substring(8,10);
			int indexEmail = result.getEmail().indexOf("@");
			String emailId = result.getEmail().substring(0, indexEmail);
			String emailAddress = result.getEmail().substring(indexEmail+1);
			//로그인 성공 -> 인증 티켓
			session.setAttribute("certification", result.getId());
			session.setAttribute("name", result.getName());
			session.setAttribute("birth", result.getBirth());
			session.setAttribute("byear", byear);
			session.setAttribute("bmonth", bmonth);
			session.setAttribute("bday", bday);
			session.setAttribute("email", result.getEmail());
			session.setAttribute("emailId", emailId);
			session.setAttribute("emailAddress", emailAddress);
			session.setAttribute("address", result.getAddress());
			session.setAttribute("rating", result.getGrade());
		}

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/member/loginok.jsp");
		dispatcher.forward(req, resp);
	}

}