package com.wmc.member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;

public class MemberDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;

	public MemberDAO() {

		DBUtil util = new DBUtil();
		conn = util.connect();

	}

	public int add(MemberDTO dto) {

		try {

			String sql = "insert into tblMember (id, name, pw, birth, email, grade, status, address, del) values (?, ?, ?, ?, ?, '1', null, ?, default)";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getId());
			stat.setString(2, dto.getName());
			stat.setString(3, dto.getPw());
			stat.setString(4, dto.getBirth());
			stat.setString(5, dto.getEmail());
			stat.setString(6, dto.getAddress());

			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("MemberDAO.add : " + e.toString());
		}

		return 0;
	}

	public int idCheck(MemberDTO dto) {

		try {

			String sql = "select count(*) as cnt from tblMember where id = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getId());

			rs = stat.executeQuery();

			if (rs.next()) {
				return Integer.parseInt(rs.getString("cnt"));
			}

		} catch (Exception e) {
			System.out.println("MemberDAO.idCheck : " + e.toString());
		}

		return 0;
	}

	public MemberDTO login(MemberDTO dto) {

		try {

			String sql = "select * from tblMember where id = ? and pw = ? and del = 1";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getId());
			stat.setString(2, dto.getPw());

			rs = stat.executeQuery();

			MemberDTO result = new MemberDTO();

			if (rs.next()) {
				result.setAddress(rs.getString("address"));
				result.setBirth(rs.getString("birth"));
				result.setEmail(rs.getString("email"));
				result.setId(rs.getString("id"));
				result.setPw(rs.getString("pw"));
				result.setName(rs.getString("name"));
				result.setGrade(rs.getString("grade"));

				return result;
			} else {
				return null;
			}

		} catch (Exception e) {
			System.out.println("MemberDAO.login : " + e.toString());
		}

		return null;
	}

	public String idSearch(MemberDTO dto) {

		try {

			String sql = "select id from tblMember where name = ? and email = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getName());
			stat.setString(2, dto.getEmail());

			rs = stat.executeQuery();

			String id = "";

			if (rs.next()) {
				id = rs.getString("id");
				return id;
			}

		} catch (Exception e) {
			System.out.println("MemberDAO.idSearch : " + e.toString());
		}

		return "";
	}

	public String pwSearch(MemberDTO dto) {

		try {

			String sql = "select pw from tblMember where id = ? and email = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getId());
			stat.setString(2, dto.getEmail());

			rs = stat.executeQuery();

			String pw = "";

			if (rs.next()) {
				pw = rs.getString("pw");
				return pw;
			}

		} catch (Exception e) {
			System.out.println("MemberDAO.pwSearch : " + e.toString());
		}

		return "";
	}

	public int edit(MemberDTO dto) {

		try {

			String sql = "update tblMember set pw = ?, address = ? where id = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getPw());
			stat.setString(2, dto.getAddress());
			stat.setString(3, dto.getId());

			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("MemberDAO.edit : " + e.toString());
		}

		return 0;
	}

	public int del(MemberDTO dto) {

		try {

			String sql = "update tblMember set del = 0 where id = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getId());

			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("MemberDAO.del : " + e.toString());
		}

		return 0;
	}

	public ArrayList<MemberDTO> memberList(HashMap<String,String> map) {

		try {
			
			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("and %s like '%%%s%%'", map.get("column"), map.get("word"));
			}

			String sql = String.format("select rownum, name, id, email, birth, grade, del, rn from (select rownum as rn, one.* from (select m.*, rownum from tblmember m where m.grade = 1 and del = 1 %s) one) two where rn between %s and %s", where, map.get("begin"), map.get("end"));

			stat = conn.prepareStatement(sql);

			
			rs = stat.executeQuery();

			ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();

			while (rs.next()) {
				MemberDTO dto = new MemberDTO();
				dto.setName(rs.getString("name"));
				dto.setId(rs.getString("id"));
				dto.setGrade(rs.getString("grade"));
				dto.setBirth(rs.getString("birth").substring(0, 10));
				dto.setEmail(rs.getString("email"));

				list.add(dto);

			}

			return list;

		} catch (Exception e) {
			System.out.println("MemberDAO.memberList : " + e.toString());
		}

		return null;
	}

	public int gradeChange(MemberDTO dto) {

		try {

			String sql = "update tblMember set grade = ? where id = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getGrade());
			stat.setString(2, dto.getId());

			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("MemberDAO.gradeChange : " + e.toString());
		}

		return 0;
	}

	public int delMember(MemberDTO dto) {

		try {

			String sql = "update tblMember set del = 0 where id = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getId());

			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("MemberDAO.delMember : " + e.toString());
		}

		return 0;
	}

	public ArrayList<MemberDTO> searchedMember(HashMap<String, String> map) {

		try {

			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("%s like '%%%s%%'", map.get("column"), map.get("word"));
			}

			
			String sql = String.format("select rownum, name, id, email, birth, grade, del, rn from (select rownum as rn, one.* from (select m.*, rownum from tblmember m where m.grade = 1 and %s) one) two where rn between %s and %s", where, map.get("begin"), map.get("end"));

			System.out.println(map.get("begin"));
			System.out.println(map.get("end"));
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();

			ArrayList<MemberDTO> slist = new ArrayList<MemberDTO>();

			while (rs.next()) {
				MemberDTO dto = new MemberDTO();
				dto.setName(rs.getString("name"));
				dto.setId(rs.getString("id"));
				dto.setBirth(rs.getString("birth").substring(0, 10));
				dto.setEmail(rs.getString("email"));

				slist.add(dto);
			}

			return slist;

		} catch (Exception e) {
			System.out.println("MemberDAO.searchedMember : " + e.toString());
		}

		return null;
	}

	public int getTotalCount(HashMap<String, String> map) {

		try {

			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%' and del != '0'", map.get("column"), map.get("word"));
			}

			String sql = String.format("select count(*) as cnt from tblMember %s", where);

			stat = conn.prepareStatement(sql);

			rs = stat.executeQuery();

			if (rs.next()) {
				System.out.println(rs.getInt("cnt"));
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("MemberDAO.getTotalCount : " + e.toString());
		}

		return 0;
	}

}
