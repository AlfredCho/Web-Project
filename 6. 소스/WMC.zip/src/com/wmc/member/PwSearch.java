package com.wmc.member;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/member/pwsearch.do")
public class PwSearch extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String pwSearchId = req.getParameter("id");
		String email4 = req.getParameter("email4");
		String email5 = req.getParameter("email5");
		String email6 = req.getParameter("email6");

		MemberDTO dto = new MemberDTO();

		dto.setId(pwSearchId);
		if (email5.equals("") || email5 == null) {
			dto.setEmail(email4 + "@" + email6);
		} else {
			dto.setEmail(email4 + "@" + email5);
		}
		
		MemberDAO dao = new MemberDAO();

		String SearchPw = dao.pwSearch(dto);
		
		resp.setCharacterEncoding("UTF-8");
		resp.setContentType("application/json");

		PrintWriter writer = resp.getWriter();
		if (SearchPw.equals("")) {
			SearchPw = "존재하지 않는 아이디입니다.";
		} else {
			SearchPw = "비밀번호 : " + SearchPw;
		}
		writer.print("{");
		writer.printf("\"pw\":\"%s\"", SearchPw);
		writer.print("}");

		writer.close();

	}

}