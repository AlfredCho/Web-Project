package com.wmc.etc;

import java.util.Calendar;
import java.util.Random;

public class Dummy {

	
	public static void main(String[] args) {
		
		
		//tblquestion();
		tblsubmission();
		//tblsolving();
		
	}

	private static void tblsolving() {
		
		Random rnd = new Random();
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE,-31);
		
		String [] codeused = {"cache = [0 for _ in range(100+1)]" + 
				"cache[1] = 1" + "for i in range(2, 100+1):" + 
				"    cache[i] = cache[i-1] + cache[i-2]" + ">>> print(cache[100])"};
		
		String [] languageused = {"1","2","3"};
		String [] id = {"alc1548","bunny11","hoka87", "alf54","lasdd","muruea233","jyeop93","baeabae00","bin1764","zodixx5","bighi700","whdhgj134","honbaad","chulll2","jyeon96","ehdtjd454","ukyung7","mimi00","minsang564","geenie92","bsbsbil22","gjswjd901","zjusmn22","heeeeee9","ahsshksjd58","watsupz012", "zey1548","zey1111","zey2222","zey3333", "zey4444","zey6666","zey7777","zey8888","zey9999","zey0000","zey1234","zey1212","zey5555","cey1548","cey1111","cey2222","cey3333","cey4444","cey5555","cey6666","cey7777","cey8888","cey9999","cey0000","cey1234","cey1212","dey1548","dey1111","dey2222","dey3333", "dey4444","dey5555","dey6666","dey7777","dey8888","dey9999","dey0000","dey1234","dey1212","ey1548","ey1111","ey2222","ey3333", "ey4444","ey5555","ey6666","ey7777","ey8888","ey9999","ey0000","ey1234","ey1212","hey1548","hey1111","hey2222","hey3333","hey4444","hey5555","hey6666","hey7777","hey8888","hey9999","hey0000","hey1234","hey1212","ley1548","ley1111","ley2222","ley3333","ley4444","ley5555","ley6666","ley7777","ley8888","ley9999","ley0000","ley1234","ley1212"};
		String [] status = {"1","0"};
		
		
		for (int i=0; i<1000; i++) {
			
		String qsolving = String.format("INSERT INTO tblqsolving (seq, codeused, languageused, regdate, ID, algorithmnum,status)\r\n" + 
					"    VALUES(qsolving_seq.NEXTVAL, '%s', '%s', TO_DATE('%s','YYYY-MM-DD'), '%s', %d, '%s');"
					, codeused[rnd.nextInt(1)]
					, languageused[rnd.nextInt(3)]
					, String.format("%tF", c)
					, id[rnd.nextInt(8)]
					, rnd.nextInt(110) + 31
					, status[rnd.nextInt(2)]);
			
			c.add(Calendar.DATE, 1);
			System.out.println(qsolving);
		}
		
		
	}

	private static void tblsubmission() {
		
		Random rnd = new Random();
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE,-31);
		
//		int [] questionnum = new int[110];
//
//		for (int i=31; i<140; i++) {
//			
//			questionnum[i-31] = i;
//			
//		}
		
		String [] id = {"alc1548","bunny11","hoka87", "alf54","lasdd","muruea233","jyeop93","baeabae00","bin1764","zodixx5","bighi700","whdhgj134","honbaad","chulll2","jyeon96","ehdtjd454","ukyung7","mimi00","minsang564","geenie92","bsbsbil22","gjswjd901","zjusmn22","heeeeee9","ahsshksjd58","watsupz012", "zey1548","zey1111","zey2222","zey3333", "zey4444","zey6666","zey7777","zey8888","zey9999","zey0000","zey1234","zey1212","zey5555","cey1548","cey1111","cey2222","cey3333","cey4444","cey5555","cey6666","cey7777","cey8888","cey9999","cey0000","cey1234","cey1212","dey1548","dey1111","dey2222","dey3333", "dey4444","dey5555","dey6666","dey7777","dey8888","dey9999","dey0000","dey1234","dey1212","ey1548","ey1111","ey2222","ey3333", "ey4444","ey5555","ey6666","ey7777","ey8888","ey9999","ey0000","ey1234","ey1212","hey1548","hey1111","hey2222","hey3333","hey4444","hey5555","hey6666","hey7777","hey8888","hey9999","hey0000","hey1234","hey1212","ley1548","ley1111","ley2222","ley3333","ley4444","ley5555","ley6666","ley7777","ley8888","ley9999","ley0000","ley1234","ley1212"};
		String [] languageType = {"1","2","3"};
		String [] submitcode = {"cache = [0 for _ in range(100+1)]" + 
				"cache[1] = 1" + "for i in range(2, 100+1):" + 
				"    cache[i] = cache[i-1] + cache[i-2]" + ">>> print(cache[100])"};
		
		String [] result = {"1","0"};
		String [] status = {"1","0"};
		
		for (int i=0; i<100; i++) {
			
			String submit = String.format("INSERT INTO TBLSUBMISSION (SEQ, QUESTIONNUM, ID, LANGUAGETYPE, SUBMITCODE, REGDATE, RESULT,STATUS)\r\n " + 
					"    VALUES(SUBMISSION_SEQ.NEXTVAL, %d, '%s', '%s', '%s',TO_DATE('%s','YYYY-MM-DD'),'%s','%s');"
					, rnd.nextInt(80) + 1
					, id[rnd.nextInt(8)]
					, languageType[rnd.nextInt(3)]
					, submitcode[rnd.nextInt(1)]
					, String.format("%tF", c)
					, result[rnd.nextInt(2)]
					, status[rnd.nextInt(2)]);
			
			c.add(Calendar.DATE, 1);
			System.out.println(submit);
			
			
		}
				
	}

	private static void tblquestion() {
		//String [] array = new String[100]; 
		
		String [] idList = {"alc1548","bunny11","hoka87", "alf54","lasdd","muruea233","jyeop93","baeabae00","bin1764","zodixx5","bighi700","whdhgj134","honbaad","chulll2","jyeon96","ehdtjd454","ukyung7","mimi00","minsang564","geenie92","bsbsbil22","gjswjd901","zjusmn22","heeeeee9","ahsshksjd58","watsupz012", "zey1548","zey1111","zey2222","zey3333", "zey4444","zey6666","zey7777","zey8888","zey9999","zey0000","zey1234","zey1212","zey5555","cey1548","cey1111","cey2222","cey3333","cey4444","cey5555","cey6666","cey7777","cey8888","cey9999","cey0000","cey1234","cey1212","dey1548","dey1111","dey2222","dey3333", "dey4444","dey5555","dey6666","dey7777","dey8888","dey9999","dey0000","dey1234","dey1212","ey1548","ey1111","ey2222","ey3333", "ey4444","ey5555","ey6666","ey7777","ey8888","ey9999","ey0000","ey1234","ey1212","hey1548","hey1111","hey2222","hey3333","hey4444","hey5555","hey6666","hey7777","hey8888","hey9999","hey0000","hey1234","hey1212","ley1548","ley1111","ley2222","ley3333","ley4444","ley5555","ley6666","ley7777","ley8888","ley9999","ley0000","ley1234","ley1212"};
		String [] questionname1 = {
				"수열구하기","A+B","최대공약수","최소공약수","달팽이","대각선","그리기"
				,"어린왕자","화폐매수구하기","이진법","그레이코드","바이너리"};
		String [] questioncontent1 = {
				"구하시오","예제를 보고","문제내용","입니다"
				,"알고리즘","문제입니다."};
		String [] input1 = {"입력의", "첫 줄에는 ","테스트", "케이스의 개수 T가 ","주어진다.", "그 다음 줄부터", "각각의", "테스트케이스에 대해 ","첫째 줄에"," 출발점 (x1, y1)과"," 도착점 (x2, y2)이 주어진다." ,"두 번째 줄에는", "행성계의 개수", "n이 주어지며", "세 번째 줄부터" ,"n줄에 걸쳐" ,"행성계의"," 중점과 반지름", "(cx, cy, r)이 주어진다.", "입력제한은 다음과 같다.", "(-1000 ≤ x1", "y1", "x2", "y2", "cx"," cy ≤ 1000", "1 ≤ r ≤ 1000", "1 ≤ n ≤ 50)"};
		String [] output1 = {"입력의", "첫 줄에는 ","테스트", "케이스의 개수 T가 ","주어진다.", "그 다음 줄부터", "각각의", "테스트케이스에 대해 ","첫째 줄에"," 출발점 (x1, y1)과"," 도착점 (x2, y2)이 주어진다." ,"두 번째 줄에는", "행성계의 개수", "n이 주어지며", "세 번째 줄부터" ,"n줄에 걸쳐" ,"행성계의"," 중점과 반지름", "(cx, cy, r)이 주어진다.", "입력제한은 다음과 같다.", "(-1000 ≤ x1", "y1", "x2", "y2", "cx"," cy ≤ 1000", "1 ≤ r ≤ 1000", "1 ≤ n ≤ 50)"};
		String [] ex1 = {"입력의", "첫 줄에는 ","테스트", "케이스의 개수 T가 ","주어진다.", "그 다음 줄부터", "각각의", "테스트케이스에 대해 ","첫째 줄에"," 출발점 (x1, y1)과"," 도착점 (x2, y2)이 주어진다." ,"두 번째 줄에는", "행성계의 개수", "n이 주어지며", "세 번째 줄부터" ,"n줄에 걸쳐" ,"행성계의"," 중점과 반지름", "(cx, cy, r)이 주어진다.", "입력제한은 다음과 같다.", "(-1000 ≤ x1", "y1", "x2", "y2", "cx"," cy ≤ 1000", "1 ≤ r ≤ 1000", "1 ≤ n ≤ 50)"};
		String [] sourceid1 = {"alc1548","bunny11","hoka87", "alf54","lasdd","muruea233","jyeop93","baeabae00","bin1764","zodixx5","bighi700","whdhgj134","honbaad","chulll2","jyeon96","ehdtjd454","ukyung7","mimi00","minsang564","geenie92","bsbsbil22","gjswjd901","zjusmn22","heeeeee9","ahsshksjd58","watsupz012", "zey1548","zey1111","zey2222","zey3333", "zey4444","zey6666","zey7777","zey8888","zey9999","zey0000","zey1234","zey1212","zey5555","cey1548","cey1111","cey2222","cey3333","cey4444","cey5555","cey6666","cey7777","cey8888","cey9999","cey0000","cey1234","cey1212","dey1548","dey1111","dey2222","dey3333", "dey4444","dey5555","dey6666","dey7777","dey8888","dey9999","dey0000","dey1234","dey1212","ey1548","ey1111","ey2222","ey3333", "ey4444","ey5555","ey6666","ey7777","ey8888","ey9999","ey0000","ey1234","ey1212","hey1548","hey1111","hey2222","hey3333","hey4444","hey5555","hey6666","hey7777","hey8888","hey9999","hey0000","hey1234","hey1212","ley1548","ley1111","ley2222","ley3333","ley4444","ley5555","ley6666","ley7777","ley8888","ley9999","ley0000","ley1234","ley1212"};
		String [] clsfc1 = {"1","0"};
		String [] language1  = {"1","0"};
		String [] status1  = {"1","0"};
		
		
		Random rnd = new Random();
		
		for (int i=0; i<100; i++) {
			
			String id = idList[rnd.nextInt(idList.length-1) + 1];
			String questionname = questionname1[rnd.nextInt(questionname1.length-1) + 1];
			String questioncontent = questioncontent1[rnd.nextInt(questioncontent1.length-1) + 1];
			String input = input1[rnd.nextInt(input1.length-1) + 1];
			String output = output1[rnd.nextInt(output1.length-1) + 1];
			String ex = ex1[rnd.nextInt(ex1.length-1) + 1];
			String sourceid = sourceid1[rnd.nextInt(sourceid1.length-1) + 1];
			String clsfc = clsfc1[rnd.nextInt(clsfc1.length-1) + 1];
			String language = language1[rnd.nextInt(language1.length-1) + 1];
			String status = status1[rnd.nextInt(status1.length-1) + 1];
			
			
			
			
			System.out.printf("insert into tblquestion (seq,id,questionname,questioncontent,input,output,ex,sourceid,clsfc,language,status) " + 
											"\r\n values(question_seq.nextval,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s');\r\n"
											,id,questionname,questioncontent,input,output,ex,sourceid,clsfc,language,status);
		
		}
	}//tblquestionDummy
	
}
