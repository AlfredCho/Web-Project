package com.wmc.etc;

public class BattleDTO {

	private String id;
	private String questionnum;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getQuestionnum() {
		return questionnum;
	}
	public void setQuestionnum(String questionnum) {
		this.questionnum = questionnum;
	}
	
}
