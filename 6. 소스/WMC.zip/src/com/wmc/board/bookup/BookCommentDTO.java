package com.wmc.board.bookup;

public class BookCommentDTO {

	private String bcseq;
	private String content;
	private String regdate;
	private String pbookSeq;
	private String id;
	private String name;

	public String getBcseq() {
		return bcseq;
	}

	public void setBcseq(String bcseq) {
		this.bcseq = bcseq;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

	public String getPbookSeq() {
		return pbookSeq;
	}

	public void setPbookSeq(String pbookSeq) {
		this.pbookSeq = pbookSeq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
