package com.wmc.board.bookup;

import java.io.File;
import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@WebServlet("/board/bookup/editok.do")
public class EditOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//인증 사용자?
		//AuthCheck auth = new AuthCheck(req.getSession(), resp);
		//auth.allow();
		
		//EditOk.java		
		//1. 데이터 가져오기
		//2. DB 작업 > DAO 위임(update)
		//3. 결과 반환 + JSP 호출
		
		
		//1 데이터 가져오기
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
			
		//String subject = req.getParameter("subject");
		//String bookseq = req.getParameter("bookseq");
		//String writer = req.getParameter("writer");
		//String price = req.getParameter("price");
		//String content = req.getParameter("content");
		
		
		String bookseq = "";
		String subject = "";
		String content = "";
		
		String writer = "";		
		String filename = "";				
		String orgfilename = "";								
		String price = "";	
		
		try {
			
			//WebContent > files
			MultipartRequest multi = new MultipartRequest(
																req,
																req.getRealPath("/files"),
																1024 * 1024 * 100,
																"UTF-8",
																new DefaultFileRenamePolicy()
															); //이 순간 > 첨부 파일 저장 완료
			
			price = multi.getParameter("price");
			writer = multi.getParameter("writer");									
			subject = multi.getParameter("subject");
			content = multi.getParameter("content");
			bookseq = multi.getParameter("bookseq");			
			
												
			filename = multi.getFilesystemName("attach");
			orgfilename = multi.getOriginalFileName("attach");
			//love = Integer.parseInt(multi.getParameter("love"));
			
				if (filename == null) {
				
				if (multi.getParameter("isdelete") != "") {
					File file = new File(req.getRealPath("/files") + "\\" + multi.getParameter("isdelete"));
					file.delete();
				}
				
				//파일을 그대로 두겠다.
				filename = multi.getParameter("filename");
				orgfilename = multi.getParameter("orgfilename");
				
			} else {
				//새로운 첨부 파일 선택				
				File file = new File(req.getRealPath("/files") + "\\" + multi.getParameter("filename"));
				file.delete();
			}		
								
		} catch (Exception e) {
			
			System.out.println("AddOk.doPost : " + e.toString());
		}
		
				
		//2. DB 작업
		BookDTO dto = new BookDTO();
		
		dto.setSubject(subject);
		dto.setContent(content);
		dto.setBookseq(bookseq);
		dto.setWriter(writer);
		dto.setPrice(price);		
		dto.setFilename(filename);
		dto.setOrgfilename(orgfilename);		
		
		BookDAO dao = new BookDAO();
		
		int result = dao.edit(dto);
		
		req.setAttribute("result", result);
		req.setAttribute("bookseq", bookseq);
		
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/board/bookup/editok.jsp");
		dispatcher.forward(req, resp);

	}//doget

}//class
