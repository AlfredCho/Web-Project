package com.wmc.board.booksel;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/board/booksel/bookdata.do")
public class BookData extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//BookData
		String query = req.getParameter("query");
		
		//애플리케이션 클라이언트 아이디값"
		String clientId = "ZuwejjxidmZO4x8EZSNT";
		
		// 애플리케이션 클라이언트 시크릿값";
		String clientSecret = "ThPTDsjBuz";

		
		try {
			String text = URLEncoder.encode(query, "UTF-8");

			// Open API 주소
			String apiURL = "https://openapi.naver.com/v1/search/book.xml?query=" + text + "&display=100"; 
			

			// 검색 요청
			URL url = new URL(apiURL);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setRequestMethod("GET");
			con.setRequestProperty("X-Naver-Client-Id", clientId);
			con.setRequestProperty("X-Naver-Client-Secret", clientSecret);

			int responseCode = con.getResponseCode();

			BufferedReader br;

			if (responseCode == 200) { // 정상 호출

				br = new BufferedReader(new InputStreamReader(con.getInputStream()));

			} else { // 에러 발생

				br = new BufferedReader(new InputStreamReader(con.getErrorStream()));
			}

			
			// - > 업무 구현
			String inputLine;

			StringBuffer response = new StringBuffer();

			while ((inputLine = br.readLine()) != null) {

				response.append(inputLine);
			}

			br.close();

						
		

			resp.setCharacterEncoding("UTF-8");
			resp.setContentType("text/xml");
			PrintWriter writer =  resp.getWriter();
			
			writer.print(response.toString());
			
			writer.close(); 
			
			
		} catch (Exception e) {
			System.out.println(e);
		}
				


	}//doget

}//class
