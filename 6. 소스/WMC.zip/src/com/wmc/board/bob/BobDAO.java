package com.wmc.board.bob;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.wmc.DBUtil;

public class BobDAO {
	

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	public BobDAO() {
		
		DBUtil util = new DBUtil();
		conn = util.connect();
		
	}

	public ArrayList<BobDTO> listbob() {
		try {
			
			String sql="SELECT * FROM tblBob";
			
			stat = conn.prepareStatement(sql);
			
			rs = stat.executeQuery();
			
			
			ArrayList<BobDTO> list = new ArrayList<BobDTO>();
			
			while(rs.next()) {
				
				BobDTO dto = new BobDTO();
				dto.setBobseq(rs.getString("bobseq"));
				dto.setName(rs.getString("name"));
				dto.setContent(rs.getString("content"));
				dto.setLat(rs.getString("lat"));
				dto.setLng(rs.getString("lng"));				
				dto.setStar(rs.getString("star"));
				
				
				
				list.add(dto);
				
				
			}
			return list;
			
			
			
		} catch (Exception e) {
			
			System.out.println("BobDAO.listbob : " + e.toString());
			
		}
		
		return null;
	}

	public int editCoffee(BobDTO dto) {
		try {
			
			String sql="update tblbob set name = ?, content = ? , star = ? where bobseq = ?";
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getName());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getStar());
			stat.setString(4, dto.getBobseq());

			
			return stat.executeUpdate();
			
			
		} catch (Exception e) {
			
			System.out.println("BobDAO.editCoffee : " + e.toString());
			
		}
		
		return 0;
	}

	public int addBob(BobDTO dto) {
		try {
			
			String sql = "insert into tblbob (bobseq, name, content, lat, lng, star) values (bob_seq.nextval, ?, ?, ?, ?, ?)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getName());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getLat());
			stat.setString(4, dto.getLng());			
			stat.setString(5, dto.getStar());
			
			return stat.executeUpdate();
					
			
			
		} catch (Exception e) {
			
			System.out.println("BobDAO.addBob : " + e.toString());
			
		}
		
				
		
		
		
		return 0;
	}

	public int delCoffee(BobDTO dto) {
		try {
			
			String sql="delete from tblbob where bobseq =?";
			stat = conn.prepareStatement(sql);
			stat.setString(1, dto.getBobseq());
			
			return stat.executeUpdate();
			
		} catch (Exception e) {
			
			System.out.println("BobDAO.delCoffee : " + e.toString());
			
		}
		
		
		
		return 0;
	}

}
