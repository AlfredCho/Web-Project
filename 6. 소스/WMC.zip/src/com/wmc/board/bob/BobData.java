package com.wmc.board.bob;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/board/bob/bobdata.do")
public class BobData extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		// bobdata.java

		String mode = req.getParameter("mode");

		if (mode == null || mode.equals("")) {
			add(req, resp);
		} else if (mode.equals("edit")) {
			edit(req, resp);
		} else if (mode.equals("del")) {
			del(req, resp);
		}

	}// main

	private void del(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String bobseq = req.getParameter("bobseq");

		BobDTO dto = new BobDTO();
		dto.setBobseq(bobseq);

		BobDAO dao = new BobDAO();
		int result = dao.delCoffee(dto);

		resp.setContentType("application/json");// MIME

		PrintWriter writer = resp.getWriter();

		writer.print("{");
		writer.printf("\"result\":\"%d\"", result);
		writer.print("}");

		writer.close();

	}// del

	private void edit(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String name = req.getParameter("name");
		String bobseq = req.getParameter("bobseq");
		String content = req.getParameter("content");
		String star = req.getParameter("star");

		BobDTO dto = new BobDTO();
		dto.setName(name);
		dto.setBobseq(bobseq);
		dto.setContent(content);		
		dto.setStar(star);

		BobDAO dao = new BobDAO();
		int result = dao.editCoffee(dto);

		resp.setContentType("application/json");// MIME

		PrintWriter writer = resp.getWriter();

		writer.print("{");
		writer.printf("\"result\":\"%d\"", result);
		writer.print("}");

		writer.close();

	}// edit

	private void add(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		// 받아오기
		String name = req.getParameter("name");
		String lat = req.getParameter("lat");
		String lng = req.getParameter("lng");
		String content = req.getParameter("content");
		String star = req.getParameter("star");
	
		// DB작업
		BobDTO dto = new BobDTO();
		
		dto.setName(name);
		dto.setLat(lat);
		dto.setLng(lng);
		dto.setContent(content);		
		dto.setStar(star);
		
		BobDAO dao = new BobDAO();

		int result = dao.addBob(dto);

		resp.setContentType("application/json");// MIME

		PrintWriter writer = resp.getWriter();

		writer.print("{");
		writer.printf("\"result\":\"%d\"", result);
		writer.print("}");

		writer.close();

	}// add

}// class
