package com.wmc.board.shadow;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/board/shadow/delok.do")
public class DelOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//DelOk.java
		//1. 데이터 가져오기
		//2. DB 작업 > DAO 위임(delete)
		//3. 결과 반환 + JSP 호출
	
		//인증 사용자
		//AuthCheck auth = new AuthCheck(req.getSession(), resp);
		//auth.allow();
		
		//글 번호 받아오기
		String shadowseq = req.getParameter("shadowseq");
		
		//DB작업
		ShadowDAO dao = new ShadowDAO();
		
		//댓글 삭제 - 댓글 달고 추가하기
		
		//dao.delAllComment(seq);//1, 0(fail) > null(0) : 상태 구분
		
		//글 삭제
		int result = dao.del(shadowseq);
		req.setAttribute("result", result);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/board/shadow/delok.jsp");
		dispatcher.forward(req, resp);

	}//doget

}//class
