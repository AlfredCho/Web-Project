package com.wmc.board.shadow;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/board/shadow/editok.do")
public class EditOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//인증 사용자?
		//AuthCheck auth = new AuthCheck(req.getSession(), resp);
		//auth.allow();
		
		//EditOk.java		
		//1. 데이터 가져오기
		//2. DB 작업 > DAO 위임(update)
		//3. 결과 반환 + JSP 호출
		
		
		//1 데이터 가져오기
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
			
		String subject = req.getParameter("subject");
		String shadowseq = req.getParameter("shadowseq");
		String content = req.getParameter("content");
		
		
		//2. DB 작업
		ShadowDTO dto = new ShadowDTO();
		
		dto.setSubject(subject);
		dto.setContent(content);
		dto.setShadowseq(shadowseq);
		
		
		ShadowDAO dao = new ShadowDAO();
		
		int result = dao.edit(dto);
		
		req.setAttribute("result", result);
		req.setAttribute("shadowseq", shadowseq);
		
		
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/board/shadow/editok.jsp");
		dispatcher.forward(req, resp);

	}//doget

}//class
