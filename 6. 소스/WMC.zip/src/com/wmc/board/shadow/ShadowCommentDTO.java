package com.wmc.board.shadow;

public class ShadowCommentDTO {

	private String shcseq;
	private String content;
	private String regdate;
	private String pshadowseq;
	private String id;
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getShcseq() {
		return shcseq;
	}

	public void setShcseq(String shcseq) {
		this.shcseq = shcseq;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegdate() {
		return regdate;
	}

	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}

	public String getPshadowseq() {
		return pshadowseq;
	}

	public void setPshadowseq(String pshadowseq) {
		this.pshadowseq = pshadowseq;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

}
