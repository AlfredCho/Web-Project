package com.wmc.jobboard;

public class JobBoardDTO {

	private String title;
	private String content;
	private String dlyear;
	private String dlmonth;
	private String dlday;
	private String writer;
	private String dldate;
	private String registerdate;
	private String seq;
	private String grade;
	private String membergrade;
	private Integer gap;
	private String lat;
	private String lng;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getDlyear() {
		return dlyear;
	}
	public void setDlyear(String dlyear) {
		this.dlyear = dlyear;
	}
	public String getDlmonth() {
		return dlmonth;
	}
	public void setDlmonth(String dlmonth) {
		this.dlmonth = dlmonth;
	}
	public String getDlday() {
		return dlday;
	}
	public void setDlday(String dlday) {
		this.dlday = dlday;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public String getDldate() {
		return dldate;
	}
	public void setDldate(String dldate) {
		this.dldate = dldate;
	}
	public String getRegisterdate() {
		return registerdate;
	}
	public void setRegisterdate(String registerdate) {
		this.registerdate = registerdate;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getMembergrade() {
		return membergrade;
	}
	public void setMembergrade(String membergrade) {
		this.membergrade = membergrade;
	}
	public Integer getGap() {
		return gap;
	}
	public void setGap(Integer gap) {
		this.gap = gap;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLng() {
		return lng;
	}
	public void setLng(String lng) {
		this.lng = lng;
	}
	
}
