package com.wmc.jobboard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Calendar;
import java.util.Random;

import com.wmc.DBUtil;

public class Dummy {

	   public static void main(String[] args) {

	      String[] id = { "alc1548", "bunny11", "hoka87", "alf54", "lasdd", "muruea233", "jyeop93", "baeabae00" };
	      String[] word = { "안녕", "하이", "게시판", "배고파", "아침", "점심", "저녁", "어렵", "자바", "컴퓨터", "집어던지다", "라떼는 말이야", "응?", "안해",
	            "치킨", "피자", "스시", "고기", "주비", "맥주", "혼날래?" };

	      String sql = "insert into tbljobboard (seq, title, content, registerdate, dldate, writer, del, grade, lat, lng) values (tblJobBoard_seq.nextval, ?, ?, ?, ?, ?, 1, 1, null, null)";

	      try {

	         DBUtil util = new DBUtil();
	         Connection conn = util.connect();
	         PreparedStatement stat = conn.prepareStatement(sql);

	         Random rnd = new Random();
	         Calendar c = Calendar.getInstance();
	         c.add(Calendar.DATE, -100);
	         Calendar d = Calendar.getInstance();
	         d.add(Calendar.DATE, 1);

	         for (int i = 0; i < 100; i++) {
	            stat.setString(1,
	                  word[rnd.nextInt(word.length)] + "" + word[rnd.nextInt(word.length)] + ""
	                        + word[rnd.nextInt(word.length)] + "" + word[rnd.nextInt(word.length)] + ""
	                        + word[rnd.nextInt(word.length)]);
	            stat.setString(2,
	                  word[rnd.nextInt(word.length)] + "" + word[rnd.nextInt(word.length)] + ""
	                        + word[rnd.nextInt(word.length)] + "" + word[rnd.nextInt(word.length)] + ""
	                        + word[rnd.nextInt(word.length)]);
	            stat.setString(3, String.format("%tF", c));
	            stat.setString(4, String.format("%tF", d));
	            stat.setString(5, id[rnd.nextInt(id.length)]);
	            c.add(Calendar.DATE, 1);
	            d.add(Calendar.DATE, 1);

	            stat.executeUpdate();

	            System.out.println(i + " inserted");
	         }

	      } catch (Exception e) {
	         System.out.println("JobDummy.enclosing_method : " + e.toString());
	      }

	   }

	}
