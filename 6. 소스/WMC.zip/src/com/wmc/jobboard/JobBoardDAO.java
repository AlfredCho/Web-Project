package com.wmc.jobboard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;

public class JobBoardDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;

	public JobBoardDAO() {

		DBUtil util = new DBUtil();
		conn = util.connect();

	}

	public int add(JobBoardDTO dto) {

		try {

			String sql = "insert into tblJobBoard (seq, title, content, registerdate, dldate, writer, del, grade, lat, lng) values (tblJobBoard_seq.nextval, ?, ?, default, ?, ?, default, ?, ?, ?)";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getTitle());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getDldate());
			stat.setString(4, dto.getWriter());
			stat.setString(5, dto.getGrade());
			stat.setString(6, dto.getLat());
			stat.setString(7, dto.getLng());

			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("JobBoardDAO.add : " + e.toString());
		}

		return 0;
	}

	public ArrayList<JobBoardDTO> list(HashMap<String,String> map) {

		try {

			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("and %s like '%%%s%%'", map.get("column"), map.get("word"));
			}

			String sql = String.format("select * from (select rownum as rn, one.* from (select j.*, m.grade as membergrade, round(dldate - sysdate) as gap from tblJobBoard j inner join tblMember m on m.id = j.writer where j.del = 1 %s order by j.grade desc, membergrade desc, j.registerdate desc) one) where rn between %s and %s", where, map.get("begin"), map.get("end"));

			stat = conn.prepareStatement(sql);

			rs = stat.executeQuery();

			ArrayList<JobBoardDTO> list = new ArrayList<JobBoardDTO>();

			while (rs.next()) {
				JobBoardDTO dto = new JobBoardDTO();

				dto.setContent(rs.getString("content"));
				dto.setWriter(rs.getString("writer"));
				dto.setRegisterdate(rs.getString("registerdate").substring(0, 10));
				dto.setDldate(rs.getString("dldate").substring(0, 10));
				dto.setSeq(rs.getString("seq"));
				dto.setTitle(rs.getString("title"));
				dto.setGrade(rs.getString("grade"));
				dto.setMembergrade(rs.getString("membergrade"));
				dto.setGap(rs.getInt("gap"));

				list.add(dto);

			}

			return list;

		} catch (Exception e) {
			System.out.println("JobBoardDAO.list : " + e.toString());
		}

		return null;
	}

	public JobBoardDTO view(String seq) {

		try {

			String sql = "select * from tblJobBoard where seq = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, seq);

			rs = stat.executeQuery();

			JobBoardDTO dto = new JobBoardDTO();

			while (rs.next()) {
				dto.setContent(rs.getString("content").replace("\r\n", "<br>"));
				dto.setTitle(rs.getString("title"));
				dto.setWriter(rs.getString("writer"));
				dto.setDldate(rs.getString("dldate").substring(0, 10));
				dto.setSeq(rs.getString("seq"));
				dto.setDlyear(rs.getString("dldate").substring(0, 4));
				dto.setDlmonth(rs.getString("dldate").substring(5, 7));
				dto.setDlday(rs.getString("dldate").substring(8, 10));
				dto.setGrade(rs.getString("grade"));
				dto.setLat(rs.getString("lat"));
				dto.setLng(rs.getString("lng"));
			}

			return dto;

		} catch (Exception e) {
			System.out.println("JobBoardDAO.view : " + e.toString());
		}

		return null;
	}

	public int edit(JobBoardDTO dto) {

		try {

			String sql = "update tblJobBoard set title = ?, content = ?, dldate = ?, writer = ?, lat = ?, lng = ? where seq = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getTitle());
			stat.setString(2, dto.getContent());
			stat.setString(3, dto.getDldate());
			stat.setString(4, dto.getWriter());
			stat.setString(5, dto.getLat());
			stat.setString(6, dto.getLng());
			stat.setString(7, dto.getSeq());

			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("JobBoardDAO.edit : " + e.toString());
		}

		return 0;
	}

	public int del(JobBoardDTO dto) {

		try {

			String sql = "update tblJobBoard set del = 0 where seq = ?";

			stat = conn.prepareStatement(sql);

			stat.setString(1, dto.getSeq());

			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("JobBoardDAO.del : " + e.toString());
		}

		return 0;
	}

	public ArrayList<JobBoardDTO> searchedContent(HashMap<String, String> map) {

		try {

			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("and %s like '%%%s%%'", map.get("column"), map.get("word"));
			}

			// System.out.println(where);

			String sql = String.format(
					"select j.*, m.grade as membergrade, round(dldate - sysdate) as gap from tblJobBoard j inner join tblMember m on m.id = j.writer where j.del = 1 %s order by j.grade desc, membergrade desc, j.registerdate desc",
					where);

			// System.out.println(sql);
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();

			ArrayList<JobBoardDTO> slist = new ArrayList<JobBoardDTO>();

			while (rs.next()) {
				JobBoardDTO dto = new JobBoardDTO();
				dto.setDldate(rs.getString("dldate").substring(0, 10));
				dto.setGap(rs.getInt("gap"));
				dto.setGrade(rs.getString("grade"));
				dto.setMembergrade(rs.getString("membergrade"));
				dto.setRegisterdate(rs.getString("registerdate").substring(0, 10));
				dto.setTitle(rs.getString("title"));
				dto.setWriter(rs.getString("writer"));
				dto.setSeq(rs.getString("seq"));

				slist.add(dto);

			}
			// System.out.println(slist.size());
			return slist;

		} catch (Exception e) {
			System.out.println("JobBoardDAO.searchedContent : " + e.toString());
		}

		return null;
	}

	public int getTotalCount(HashMap<String, String> map) {

		try {

			String where = "";

			if (map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%' and del != '0'", map.get("column"), map.get("word"));
			}

			String sql = String.format("select count(*) as cnt from tblJobBoard %s", where);

			stat = conn.prepareStatement(sql);

			rs = stat.executeQuery();

			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("JobBoardDAO.getTotalCount : " + e.toString());
		}

		return 0;
	}

	public int addComment(CommentDTO cdto) {

		try {

			String sql = "insert into tblJobBoardComment (seq, content, registerdate, writer, del, jobboard_seq) values (jobboardcomment_seq.nextval, ?, default, ?, default, ?)";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, cdto.getContent());
			stat.setString(2, cdto.getWriter());
			stat.setString(3, cdto.getPseq());
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("JobBoardDAO.addComment : " + e.toString());
		}
		
		return 0;
	}

	public ArrayList<CommentDTO> listComment(String seq) {

		try {

			String sql = "select c.*, (select name from tblMember where id = c.writer) as name from tblJobBoardComment c where jobboard_seq = ? order by seq desc";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, seq);
			
			ArrayList<CommentDTO> clist = new ArrayList<CommentDTO>();
			
			rs = stat.executeQuery();
			
			while (rs.next()) {
				CommentDTO dto = new CommentDTO();
				dto.setContent(rs.getString("content"));
				dto.setName(rs.getString("name"));
				dto.setPseq(rs.getString("jobboard_seq"));
				dto.setRegdate(rs.getString("registerdate"));
				dto.setSeq(rs.getString("seq"));
				dto.setWriter(rs.getString("writer"));
				dto.setDel(rs.getString("del"));
				
				clist.add(dto);
			}
			
			return clist;
			
		} catch (Exception e) {
			System.out.println("JobBoardDAO.listComment : " + e.toString());
		}
		
		return null;
	}

	public int countComment(String seq) {

		try {

			String sql = "select count(*) as cnt from tbljobboardcomment where jobboard_seq = ? and del = 1";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, seq);
			
			rs = stat.executeQuery();
			
			if (rs.next()) {
				return rs.getInt("cnt");
			}

		} catch (Exception e) {
			System.out.println("JobBoardDAO.countComment : " + e.toString());
		}
		
		return 0;
	}

	public int editComment(CommentDTO dto) {

		try {

			String sql = "update tblJobBoardComment set content = ? where seq = ?";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, dto.getContent());
			stat.setString(2, dto.getSeq());
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("JobBoardDAO.editComment : " + e.toString());
		}
		
		return 0;
	}

	public String commentInfo(String seq) {

		try {

			String sql = "select jobboard_seq from tblJobBoardComment where seq = ?";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, seq);
			
			rs = stat.executeQuery();
			
			while (rs.next()) {
				return rs.getString("jobboard_seq");
			}

		} catch (Exception e) {
			System.out.println("JobBoardDAO.commentInfo : " + e.toString());
		}
		
		return null;
	}

	public int delComment(String seq) {

		try {

			String sql = "update tblJobBoardComment set del = 0 where seq = ?";
			
			stat = conn.prepareStatement(sql);
			
			stat.setString(1, seq);
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("JobBoardDAO.delComment : " + e.toString());
		}
		
		return 0;
	}



}
