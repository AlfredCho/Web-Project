package com.wmc.study.review;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

@WebServlet("/study/review/studyreviewdelok.do")
public class StudyReviewDelOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyReviewNum = req.getParameter("studyReviewNum");
		
		StudyDAO dao = new StudyDAO();
		int result = dao.delReview(studyReviewNum);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html charset='utf-8'");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		writer.println("location.href='/wmc/study/review/studyreviewlist.do'");
			
		writer.println("</script>");
		
		writer.close();

	}

}
