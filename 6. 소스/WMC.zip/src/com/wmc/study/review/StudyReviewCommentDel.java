package com.wmc.study.review;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

@WebServlet("/study/review/studyreviewcommentdel.do")
public class StudyReviewCommentDel extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyReviewNum = req.getParameter("studyReviewNum");
		String studyReviewCommentNum = req.getParameter("studyReviewCommentNum");
		
		StudyDAO dao = new StudyDAO();
		
		int result = dao.delStudyReviewComment(studyReviewCommentNum); // 댓글 삭제

		resp.setCharacterEncoding("utf-8");
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			
			writer.println("alert('댓글 작성 실패!')");
			writer.println("history.back()");
			
		}else {
			writer.println("location.href='/wmc/study/review/studyreviewview.do?studyReviewNum=" + studyReviewNum + "'");
		}
		
		writer.println("</script>");
		
		writer.close();

	}

}
