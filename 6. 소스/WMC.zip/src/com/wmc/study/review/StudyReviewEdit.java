package com.wmc.study.review;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;

@WebServlet("/study/review/studyreviewedit.do")
public class StudyReviewEdit extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyReviewNum = req.getParameter("studyReviewNum");

		StudyDAO dao = new StudyDAO();

		StudyReviewDTO dto = dao.rvlist(studyReviewNum);

		// dto.setContent(dto.getContent().replace("\r\n", "<br>"));

		req.setAttribute("dto", dto);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/review/studyreviewedit.jsp");
		dispatcher.forward(req, resp);

	}

}
