package com.wmc.study.review;

public class StudyReviewDTO {

	private String studyReviewNum;
	private String id;
	private String studyNum;
	private String title;
	private String content;
	private String gap;
	private String cnt;
	private String notice;
	private String studyName;
	
	public String getNotice() {
		return notice;
	}
	public void setNotice(String notice) {
		this.notice = notice;
	}
	public String getStudyName() {
		return studyName;
	}
	public void setStudyName(String studyName) {
		this.studyName = studyName;
	}
	public String getStudyReviewNum() {
		return studyReviewNum;
	}
	public void setStudyReviewNum(String studyReviewNum) {
		this.studyReviewNum = studyReviewNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getGap() {
		return gap;
	}
	public void setGap(String gap) {
		this.gap = gap;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}
	public String getStudyNum() {
		return studyNum;
	}
	public void setStudyNum(String studyNum2) {
		this.studyNum = studyNum2;
	}
	
	
	
}
