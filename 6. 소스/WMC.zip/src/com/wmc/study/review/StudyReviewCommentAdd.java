package com.wmc.study.review;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;
import com.wmc.study.recruit.StudyRecruitCommentDTO;

@WebServlet("/study/review/studyreviewcommentadd.do")
public class StudyReviewCommentAdd extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		String id = session.getAttribute("certification") + "";
		
		String content = req.getParameter("commenttxt");
		String studyReviewNum = req.getParameter("studyReviewNum");
		
		StudyDAO dao = new StudyDAO();

		StudyReviewCommentDTO dto = new StudyReviewCommentDTO();
		
		dto.setId(id);
		dto.setContent(content);
		dto.setStudyReviewNum(studyReviewNum);
		
		
		int result = dao.addStudyReviewComment(dto); // 댓글 넣기

		resp.setCharacterEncoding("utf-8");
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			
			writer.println("alert('댓글 작성 실패!')");
			writer.println("history.back()");
			
		}else {
			writer.println("location.href='/wmc/study/review/studyreviewview.do?studyReviewNum=" + studyReviewNum + "'");
		}
		
		writer.println("</script>");
		
		writer.close();
		
		

	}

}
