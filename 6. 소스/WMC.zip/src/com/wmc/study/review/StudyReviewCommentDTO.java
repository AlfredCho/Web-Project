package com.wmc.study.review;

public class StudyReviewCommentDTO {

	private String studyReviewCommentNum;
	private String studyReviewNum;
	private String id;
	private String content;
	private String regdate;
	
	public String getStudyReviewCommentNum() {
		return studyReviewCommentNum;
	}
	public void setStudyReviewCommentNum(String studyReviewCommentNum) {
		this.studyReviewCommentNum = studyReviewCommentNum;
	}
	public String getStudyReviewNum() {
		return studyReviewNum;
	}
	public void setStudyReviewNum(String studyReviewNum) {
		this.studyReviewNum = studyReviewNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	
	
	
}
