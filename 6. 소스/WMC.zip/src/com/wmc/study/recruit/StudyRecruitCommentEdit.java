package com.wmc.study.recruit;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;

@WebServlet("/study/recruit/studyrecruitcommentedit.do")
public class StudyRecruitCommentEdit extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		String id = session.getAttribute("certification") + "";
		
		String content = req.getParameter("commenttxt");
		String studyCommentNum = req.getParameter("studyCommentNum");
		String studyNum = req.getParameter("studyNum");
		
		StudyDAO dao = new StudyDAO();
		
		
		
		StudyRecruitCommentDTO dto = new StudyRecruitCommentDTO();
		
		dto.setId(id);
		dto.setContent(content);
		dto.setStudyCommentNum(studyCommentNum);
		
		int result = dao.updateStudyComment(dto); // 댓글 수정

		resp.setCharacterEncoding("utf-8");
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			
			writer.println("alert('댓글 작성 실패!')");
			writer.println("history.back()");
			
		}else {
			writer.println("location.href='/wmc/study/recruit/studyrecruitview.do?studyNum=" + studyNum + "'");
		}
		
		writer.println("</script>");
		
		writer.close();
		
		

	}

}

