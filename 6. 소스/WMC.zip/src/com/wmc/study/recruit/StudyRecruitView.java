package com.wmc.study.recruit;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;
import com.wmc.study.StudyGroupDTO;

@WebServlet("/study/recruit/studyrecruitview.do")
public class StudyRecruitView extends HttpServlet {
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session = req.getSession();
		
		String studyNum = req.getParameter("studyNum");
		String id = session.getAttribute("certification").toString();
		
		StudyDAO dao = new StudyDAO();
		StudyDTO dto = dao.vlist(studyNum);
		int result = dao.isGroup(id);
		String grade = dao.studyGrade(id); // 스터디 그룹 등급 뽑아오기
		ArrayList<StudyGroupDTO> smlist = dao.smlist(studyNum); // 스터디원 뽑아오기
		dao.addCnt(studyNum); // 조회수 추가
		int commentCnt = dao.countRecruitComment(studyNum); // 댓글 수
		ArrayList<StudyRecruitCommentDTO> rclist = dao.rclist(studyNum); // 댓글 리스트 뽑아오기
		
		dto.setContent(dto.getContent().replace("\r\n", "<br>"));
		
		req.setAttribute("dto", dto);
		req.setAttribute("smlist", smlist);
		req.setAttribute("rclist", rclist);
		req.setAttribute("result", result);
		req.setAttribute("grade", grade);
		req.setAttribute("commentCnt", commentCnt);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/recruit/studyrecruitview.jsp");
		dispatcher.forward(req, resp);
		
	}
	
}
