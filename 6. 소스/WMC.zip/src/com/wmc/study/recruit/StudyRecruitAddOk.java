package com.wmc.study.recruit;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;

@WebServlet("/study/recruit/studyrecruitaddok.do")
public class StudyRecruitAddOk extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		
		HttpSession session = req.getSession();
		
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String studyName = req.getParameter("studyName");
		int limit = Integer.parseInt(req.getParameter("limit"));
		
		// 추후 지워야될것!
		String id = session.getAttribute("certification").toString();
		
		//String id = session.getAttribute("id").toString(); //추후 아이디로 로그인 했을 때 고치기
		
		StudyDTO dto = new StudyDTO();
		dto.setId(id);
		dto.setTitle(title);
		dto.setContent(content);
		dto.setStudyName(studyName);
		dto.setLimit(limit);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");
		PrintWriter writer = resp.getWriter();

		StudyDAO dao = new StudyDAO();
		
		int result = dao.addLimit(id);
		writer.println("<script>");
		
		if(result == 0) {
			dao.addRecruit1(dto);
			dao.addRecruit2(id);
		}else {
			writer.println("alert('스터디는 1개만 만들수 있습니다.!')");
			writer.println("history.back()");
		}
		
		
		writer.println("location.href='/wmc/study/recruit/studyrecruitlist.do';");
		writer.println("</script>");
		
		writer.close();
		
		//RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/recruit/addok.jsp");
		//dispatcher.forward(req, resp);
		
	}
	
}
