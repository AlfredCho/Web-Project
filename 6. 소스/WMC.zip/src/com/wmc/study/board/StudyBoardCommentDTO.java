package com.wmc.study.board;

public class StudyBoardCommentDTO {

	private String studyBoardCommentNum;
	private String studyBoardNum;
	private String id;
	private String content;
	private String regdate;
	private String del;
	
	public String getStudyBoardCommentNum() {
		return studyBoardCommentNum;
	}
	public void setStudyBoardCommentNum(String studyBoardCommentNum) {
		this.studyBoardCommentNum = studyBoardCommentNum;
	}
	public String getStudyBoardNum() {
		return studyBoardNum;
	}
	public void setStudyBoardNum(String studyBoardNum) {
		this.studyBoardNum = studyBoardNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getDel() {
		return del;
	}
	public void setDel(String del) {
		this.del = del;
	}
	
	
	
}
