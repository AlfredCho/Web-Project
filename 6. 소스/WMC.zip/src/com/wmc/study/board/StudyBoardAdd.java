package com.wmc.study.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/study/board/studyboardadd.do")
public class StudyBoardAdd extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyNum = req.getParameter("studyNum");
		
		req.setAttribute("studyNum", studyNum);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/board/studyboardadd.jsp");
		dispatcher.forward(req, resp);

	}

}

