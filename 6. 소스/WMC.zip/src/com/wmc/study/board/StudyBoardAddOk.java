package com.wmc.study.board;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;
import com.wmc.study.StudyDTO;

@WebServlet("/study/board/studyboardaddok.do")
public class StudyBoardAddOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		
		HttpSession session = req.getSession();
		
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		String kind = req.getParameter("kind");
		String studyNum = req.getParameter("studyNum");
		String id = session.getAttribute("certification").toString();
		String rating = session.getAttribute("rating") + ""; // 회원 or 관리자
		
		StudyBoardDTO dto = new StudyBoardDTO();
		dto.setId(id);
		dto.setTitle(title);
		dto.setContent(content);
		dto.setKind(kind);
		dto.setStudyNum(studyNum);
		dto.setRating(rating);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");
		PrintWriter writer = resp.getWriter();

		StudyDAO dao = new StudyDAO();
		
		int result = dao.addBoard(dto);
		
		writer.println("<script>");
		if(result == 0) {
			writer.println("alert('글쓰기 실패!')");
			writer.println("history.back()");
		}else {
			writer.println("location.href='/wmc/study/board/studyboardlist.do';");
		}
		writer.println("</script>");
		writer.close();
		
	}

}

