package com.wmc.study.calendar;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.wmc.study.StudyDAO;

@WebServlet("/study/calendar/studycalendarattendadd.do")
public class StudyCalendarAttendAdd extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession session = req.getSession();
		
		String id = session.getAttribute("certification") + "";
		String studyCalendarNum = req.getParameter("studyCalendarNum");
		
		StudyAttendDTO dto = new StudyAttendDTO();
		
		dto.setId(id);
		dto.setStudyCalendarNum(studyCalendarNum);
		
		StudyDAO dao = new StudyDAO();
		int result = dao.addAttend(dto);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html charset='utf-8'");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			writer.println("alert('참석 실패!')");
			writer.println("history.back();");
		}else {
			writer.println("alert('참석되었습니다.')");
			writer.println("location.href='/wmc/study/calendar/studycalendarlist.do';");
		}
		writer.println("</script>");
		

	}

}
