package com.wmc.study.calendar;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

@WebServlet("/study/calendar/studycalendarattend.do")
public class StudyCalendarAttend extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyCalendarNum = req.getParameter("studyCalendarNum");
		
		StudyDAO dao = new StudyDAO();
		ArrayList<StudyAttendDTO> list = dao.getAttend(studyCalendarNum);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("application/json charset='utf-8'");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("[");
		for(int i = 0; i < list.size(); i++) {
			writer.println("{");
			writer.println("\"id\" : " + "\"" + list.get(i).getId() + "\",");
			writer.println("\"name\" : " + "\"" + list.get(i).getName() + "\"");
			writer.println("}");
			if(i != list.size()-1) {
				writer.println(",");
			}
			
		}
		writer.println("]");
		

	}

}
