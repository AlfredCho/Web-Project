package com.wmc.study.calendar;

public class StudyCalendarDTO {

	private String studyCalendarNum;
	private String studyNum;
	private String content;
	private String begin;
	private String end;
	private String kind;
	private String del;
	private String place;
	private String lat;
	private String lng;
	private String regdate;
	private String gap;
	private String cnt;
	private String title;
	private String id;
	private String attendNum;
	private int attendcnt;
	
	
	
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getGap() {
		return gap;
	}
	public void setGap(String gap) {
		this.gap = gap;
	}
	public String getCnt() {
		return cnt;
	}
	public void setCnt(String cnt) {
		this.cnt = cnt;
	}
	public String getDel() {
		return del;
	}
	public void setDel(String del) {
		this.del = del;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getLat() {
		return lat;
	}
	public void setLat(String lat) {
		this.lat = lat;
	}
	public String getLng() {
		return lng;
	}
	public void setLng(String lng) {
		this.lng = lng;
	}
	public String getStudyCalendarNum() {
		return studyCalendarNum;
	}
	public void setStudyCalendarNum(String studyCalendarNum) {
		this.studyCalendarNum = studyCalendarNum;
	}
	public String getStudyNum() {
		return studyNum;
	}
	public void setStudyNum(String studyNum) {
		this.studyNum = studyNum;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getBegin() {
		return begin;
	}
	public void setBegin(String begin) {
		this.begin = begin;
	}
	public String getEnd() {
		return end;
	}
	public void setEnd(String end) {
		this.end = end;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getAttendNum() {
		return attendNum;
	}
	public void setAttendNum(String attendNum) {
		this.attendNum = attendNum;
	}
	public int getAttendcnt() {
		return attendcnt;
	}
	public void setAttendcnt(int attendcnt) {
		this.attendcnt = attendcnt;
	}
	
	
	
}
