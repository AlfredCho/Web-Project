package com.wmc.study.calendar;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

@WebServlet("/study/calendar/studycalendardelok.do")
public class StudyCalendarDelOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyCalendarNum = req.getParameter("studyCalendarNum");
		
		StudyDAO dao = new StudyDAO();
		int result = dao.delStudyCalendar(studyCalendarNum);
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html charset='utf-8'");
		
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			writer.println("alert('삭제 실패!')");
		}else {
			writer.println("location.href='/wmc/study/calendar/studycalendarlist.do'");
		}
		writer.println("</script>");
		
		writer.close();

	}

}
