package com.wmc.study.calendar;

public class StudyAttendDTO {

	private String studyAttendNum;
	private String studyCalendarNum;
	private String id;
	private String name;
	
	
	public String getStudyAttendNum() {
		return studyAttendNum;
	}
	public void setStudyAttendNum(String studyAttendNum) {
		this.studyAttendNum = studyAttendNum;
	}
	public String getStudyCalendarNum() {
		return studyCalendarNum;
	}
	public void setStudyCalendarNum(String studyCalendarNum) {
		this.studyCalendarNum = studyCalendarNum;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
