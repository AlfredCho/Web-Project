package com.wmc.study.calendar;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wmc.study.StudyDAO;

@WebServlet("/study/calendar/studycalendaredit.do")
public class StudyCalendarEdit extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String studyCalendarNum = req.getParameter("studyCalendarNum");
		
		StudyDAO dao = new StudyDAO();
		
		StudyCalendarDTO dto = dao.getStudyCalendar(studyCalendarNum);
		
		req.setAttribute("dto", dto);
		req.setAttribute("studyCalendarNum", studyCalendarNum);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/study/calendar/studycalendaredit.jsp");
		dispatcher.forward(req, resp);

	}

}