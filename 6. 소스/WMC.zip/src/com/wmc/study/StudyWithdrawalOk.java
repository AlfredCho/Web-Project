package com.wmc.study;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/study/del/studydelok.do")
public class StudyWithdrawalOk extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		HttpSession session = req.getSession();
		String id = session.getAttribute("certification") + "";
		
		req.setAttribute("id", id);
		
		StudyDAO dao = new StudyDAO();
		
		String grade = dao.getStudyGrade(id); // 스터디에서 등급 가져오기
		
		if(grade.equals("3")) { // 스터디장일 경우
			String num = dao.getStudyNum(id); // 스터디 번호 가져오기
			dao.delStudyGroup(num);
			dao.studyDel(id); // 스터디 모집공고 글 삭제
		}
		
		int result = dao.studyWithdrawal(id); // 스터디 탈퇴하기
		
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html");
		PrintWriter writer = resp.getWriter();
		
		writer.println("<script>");
		if(result == 0) {
			
			writer.println("alert('스터디 탈퇴 실패!')");
			writer.println("history.back()");
			
		}else {
			writer.println("location.href='/wmc/study/recruit/studyrecruitlist.do'");
		}
		
		writer.println("</script>");
		
		writer.close();

	}

}
