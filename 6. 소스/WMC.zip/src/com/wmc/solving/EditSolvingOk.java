package com.wmc.solving;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/solving/editsolvingok.do")
public class EditSolvingOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//EditSolvingOk.java
		req.setCharacterEncoding("UTF-8");
		
		String languageType = req.getParameter("sels");
	
		
		//selected
		String sel = req.getParameter("sels");
		String questionName = req.getParameter("questionName");
		String codeUsed = req.getParameter("codeUsed");
		String seq = req.getParameter("seq");
		String algorithmNum = req.getParameter("algorithmNum");
		

		SolvingDAO dao = new SolvingDAO();
		SolvingDTO dto = new SolvingDTO();
		
		dto.setLanguageUsed(sel);
		
		dto.setCodeUsed(codeUsed);
		dto.setQuestionName(questionName);
		dto.setAlgorithmNum(algorithmNum);
		dto.setSeq(seq);
		
		int result = dao.editSolving(dto);
		
		
		req.setAttribute("sel", sel);
		req.setAttribute("seq", seq);
		req.setAttribute("result", result);

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/solving/editsolvingok.jsp");
		dispatcher.forward(req, resp);

	}

}
