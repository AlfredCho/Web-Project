package com.wmc.solving;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/solving/addsolvingok.do")
public class AddSolvingOk extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//AddSolving.java
		
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
		String languageUsed = req.getParameter("sels");
		String rnum = req.getParameter("rnum");
		String codeUsed = req.getParameter("CodeUsed");
		String id = session.getAttribute("certification").toString();
		
		SolvingDAO dao = new SolvingDAO();
		SolvingDTO dto = new SolvingDTO();
		
		dto.setLanguageUsed(languageUsed);
		dto.setRnum(rnum);
		dto.setCodeUsed(codeUsed);
		dto.setId(id);
		
		
		int result = dao.addSolving(dto);
		
		req.setAttribute("result", result);
		
		
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/solving/addsolvingok.jsp");
		dispatcher.forward(req, resp);

	}

}