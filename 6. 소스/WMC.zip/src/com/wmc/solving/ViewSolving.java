package com.wmc.solving;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/solving/viewsolving.do")
public class ViewSolving extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//AddQuestion.java
		
		String active = req.getParameter("active");
		if (active == null || active.equals("")) active = "4";
		

		req.setAttribute("active", active);
		
		
		// 돌아다니는 아이디 ------수정하기 버튼 만들기 위해서 -------------
		
		req.setCharacterEncoding("UTF-8");
		HttpSession session = req.getSession();
		
		String id = session.getAttribute("certification").toString();

		//관리자    -- 확인 !!!!!!!
		String rating = session.getAttribute("rating").toString();
		//--------------------------------------------------
		
		String seq = req.getParameter("seq");
		String algorithmNum = req.getParameter("algorithmNum");
		
		SolvingDAO dao = new SolvingDAO();
		SolvingDTO dto = dao.get(seq);

		//dto.setCodeUsed(dto.getCodeUsed().replace("\r\n","<br>"));
		
		req.setAttribute("algorithmNum", algorithmNum);
		req.setAttribute("seq", seq);
		req.setAttribute("dto", dto);
		
		

		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/solving/viewsolving.jsp");
		dispatcher.forward(req, resp);

	}

}
