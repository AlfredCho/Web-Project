package com.wmc.solving;

public class SolvingDTO {

	private String rnum2;
	private String rnum;
	private String seq;
	private String codeUsed;
	private String languageUsed;
	private String id;
	private String algorithmNum;
	private String status;
	private String questionName;
	private String regdate;
	private String questionlistRnum;	
	
	
	public String getRnum() {
		return rnum;
	}
	public void setRnum(String rnum) {
		this.rnum = rnum;
	}
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getCodeUsed() {
		return codeUsed;
	}
	public void setCodeUsed(String codeUsed) {
		this.codeUsed = codeUsed;
	}
	public String getLanguageUsed() {
		return languageUsed;
	}
	public void setLanguageUsed(String languageUsed) {
		this.languageUsed = languageUsed;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAlgorithmNum() {
		return algorithmNum;
	}
	public void setAlgorithmNum(String algorithmNum) {
		this.algorithmNum = algorithmNum;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getQuestionName() {
		return questionName;
	}
	public void setQuestionName(String questionName) {
		this.questionName = questionName;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getQuestionlistRnum() {
		return questionlistRnum;
	}
	public void setQuestionlistRnum(String questionlistRnum) {
		this.questionlistRnum = questionlistRnum;
	}
	public String getRnum2() {
		return rnum2;
	}
	public void setRnum2(String rnum2) {
		this.rnum2 = rnum2;
	}
	
	
}
