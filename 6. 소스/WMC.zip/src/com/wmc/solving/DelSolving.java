package com.wmc.solving;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/solving/delsolving.do")
public class DelSolving extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		//DelSolving.java
		
		String seq = req.getParameter("seq");
		
		req.setAttribute("seq", seq);
		
		//
		
		SolvingDAO dao = new SolvingDAO();
		
		int result = dao.delSolving(seq);
		
		req.setAttribute("result", result);
		

		RequestDispatcher dispatcher = req.getRequestDispatcher("/WEB-INF/views/solving/delsolving.jsp");
		dispatcher.forward(req, resp);

	}

}
