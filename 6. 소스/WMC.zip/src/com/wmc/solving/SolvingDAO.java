package com.wmc.solving;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;

import com.wmc.DBUtil;

public class SolvingDAO {

	private Connection conn;
	private PreparedStatement stat;
	private ResultSet rs;
	
	
	public SolvingDAO() {
		
		DBUtil util = new DBUtil();
		conn = util.connect();
		
	}


	public ArrayList<SolvingDTO> list(HashMap<String, String> map) {
		
		try {
			
			String where = "";
			if(map.get("isSearch").equals("true")) {
				
				where= String.format(" and %s like '%%%s%%'"
									, map.get("column")
									, map.get("word"));
			}
			String sql = String.format("select * from (select a.*, rownum as rnum2 from (select * from solvinglist order by rnum desc) a) where rnum2 between %s and %s %s"
					, map.get("begin"), map.get("end"), where);
			
			
		
			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			ArrayList<SolvingDTO> list = new ArrayList<SolvingDTO>();
			
			while (rs.next()) {
				
				SolvingDTO ldto = new SolvingDTO();
				
				ldto.setRnum2(rs.getString("rnum2"));
				ldto.setQuestionlistRnum(rs.getString("questionlistRnum"));
				ldto.setRnum(rs.getString("rnum"));
				ldto.setSeq(rs.getString("seq"));
				ldto.setQuestionName(rs.getString("questionName"));
				ldto.setAlgorithmNum(rs.getString("algorithmNum"));
				ldto.setCodeUsed(rs.getString("codeUsed"));
				ldto.setLanguageUsed(rs.getString("languageUsed"));
				ldto.setId(rs.getString("id"));
				ldto.setRegdate(rs.getString("regdate"));
				
				
				list.add(ldto);
				
			}
			return list;
			/*
			 * String sql = String.format("select * from solvinglist %s order by rnum desc",
			 * where);
			 */
			
			/* String sql = String.format*/
					/* ("select * from solvinglist %s where rnum between %s and %s order by rnum desc",*/
			/* where, map.get("begin"), map.get("end")); */
			
			
		}catch (Exception e) {
			System.out.println("SolvingDAO.list : " + e.toString());
		}
		
		return null;
	}


	public int getTotalCount(HashMap<String, String> map) {

		try {

			String where = "";
			
			if(map.get("isSearch").equals("true")) {
				where = String.format("where %s like '%%%s%%'"
										, map.get("column")
										, map.get("word"));
			}
	
			String sql = String.format("select count(*) as cnt from solvinglist %s", where);

			stat = conn.prepareStatement(sql);
			rs = stat.executeQuery();
			
			if(rs.next()) {
				
				return rs.getInt("cnt");
			}
		
		
		} catch (Exception e) {
			System.out.println("SolvingDAO.getTotalCount : " + e.toString());
		}

		return 0;
	}


	public SolvingDTO get(String seq) {
		
		try {

			String sql = "select * from joinsolving where seq =?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			rs = stat.executeQuery();
			
			
			SolvingDTO dto = new SolvingDTO();
			
			if(rs.next()) {
				
				dto.setRnum(rs.getString("rnum"));
				dto.setSeq(rs.getString("seq"));
				dto.setAlgorithmNum(rs.getString("algorithmNum"));
				dto.setCodeUsed(rs.getString("codeUsed"));
				dto.setId(rs.getString("id"));
				dto.setLanguageUsed(rs.getString("languageUsed"));
				dto.setQuestionName(rs.getString("questionName"));
				dto.setRegdate(rs.getString("regdate"));
				dto.setStatus(rs.getString("status"));
				
				
				
				return dto;
			}
		}catch (Exception e) {
			System.out.println("SolvingDAO.get : " + e.toString());
		}
		return null;
	}







	public int delSolving(String seq) {

		try {

			String sql = "delete from tblqSolving where seq = ?";
			
			stat = conn.prepareStatement(sql);
			stat.setString(1, seq);
			
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("QuestionDAO.delQuestion : " + e.toString());
		}
		return 0;
	}


	public int addSolving(SolvingDTO dto) {
		
	
		try {

			String sql = "insert into tblqSolving (seq,codeused,languageused,regdate,id,algorithmNum,status)" + 
						"    values(qsolving_seq.nextval,?,?,sysdate,?,(select seq from JOINQUESTION where rnum = ?),default)";
				
			stat = conn.prepareStatement(sql);
				
			stat.setString(1, dto.getCodeUsed());
			stat.setString(2, dto.getLanguageUsed());
			stat.setString(3, dto.getId());
			stat.setString(4, dto.getRnum());
				
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("SolvingDAO.addSoving : " + e.toString());
		}

		
		return 0;
	
	}


	public int editSolving(SolvingDTO dto) {

		try {

			String sql = "update tblqSolving set codeUsed=?,languageUsed=? where seq = ?";

			stat = conn.prepareStatement(sql);
				
			stat.setString(1, dto.getCodeUsed());
			stat.setString(2, dto.getLanguageUsed());
		//	stat.setString(3, dto.getAlgorithmNum());
			stat.setString(3, dto.getSeq());
				
			return stat.executeUpdate();

		} catch (Exception e) {
			System.out.println("SolvingDAO.editSolving : " + e.toString());
		}

		return 0;
	}


	
	
}








