create table tblMember(
    id varchar2(30) primary key,
    name varchar2(20) not null,
    pw varchar2(20) not null,
    birth date not null,
    email varchar2(30) not null,
    grade varchar2(3) not null,
    status varchar2(30) null,
    address varchar2(50) not null
);



create table tblStudy(
    studyNum varchar2(10) primary key,
    studyName varchar2(50) not null,
    title varchar2(500) not null,
    content varchar2(4000) not null,
    regdate date default sysdate,
    cnt number default 0,
    limit number default 0,
    id varchar2(50) not null references tblMember(id)
);



create table tblStudyCalendar(
    studyCalendarNum varchar2(10) primary key,
    content varchar2(4000) not null,
    begin date not null,
    end date not null,
    type varchar2(100) not null,
    studyNum varchar2(10) not null references tblStudy(studyNum)
);



create table tblAttend(
    studyAttendNum varchar2(10) primary key,
    studyCalendarNum varchar2(10) not null references tblStudyCalendar(studyCalendarNum),
    studyNum varchar2(10) not null references tblStudy(studyNum)
);



create table tblStudyPlace(
    studyPlaceNum varchar2(10) primary key,
    lat varchar2(100) not null,
    lng varchar2(100) not null,
    studyCalendarNum varchar(10) not null references tblStudyCalendar(studyCalendarNum)
);





create table tblstudygroup(
    studyGroupNum varchar2(10) primary key,
    studyNum varchar2(10) not null references tblStudy(studyNum),
    id varchar2(50) not null references tblMember(id),
    grade varchar2(10) not null
);




create table tblStudyReview(
    studyReviewNum varchar2(10) primary key,
    id varchar2(50) not null references tblMember(id),
    studyNum varchar2(10) not null references tblStudy(studyNum),
    title varchar2(500) not null,
    content varchar2(4000) not null,
    regdate date default sysdate,
    cnt number default 0,
    grade varchar2(10) not null
);




create table tblStudyReviewComment(
    studyReviewCommentNum varchar2(10) primary key,
    studyReviewNum varchar2(10) references tblStudyReview(studyReviewNum),
    id varchar2(50) not null references tblMember(id),
    content varchar2(4000) not null,
    regdate date default sysdate
);





create table tblStudyBoard(
    studyBoardNum varchar2(10) primary key,
    studyNum varchar2(10) not null references tblStudy(studyNum),
    id varchar2(50) not null references tblMember(id),
    studyCalendarNum varchar2(10) not null references tblStudyCalendar(studyCalendarNum),
    title varchar2(500) not null,
    grade varchar2(10) not null,
    content varchar2(4000) not null,
    regdate date default sysdate,
    cnt number default 0
);



create table tblStudyBoardComment(
   studyBoardCommentNum varchar2(10) primary key,
   studyBoardNum varchar2(10) not null references tblStudyBoard(studyBoardNum),
   content varchar2(4000) not null,
    regdate date default sysdate
);


-- ============================ 시퀀스

create sequence studyNum_seq;
create sequence studyCalendarNum_seq;
create sequence studyAttendNum_seq;
create sequence studyPlaceNum_seq;
create sequence studyGroupNum_seq;
create sequence studyReviewNum_seq;
create sequence studyReviewCommentNum_seq;
create sequence studyBoardNum_seq;
create sequence studyBoardCommentNum_seq;


insert into tblMember values('bey1548', '세훈', '1234', '1994-04-03', '1234@naver.com', '1', null, '구미');
insert into tblMember values('bey1111', '훈세', '1234', '1994-05-03', '5678@naver.com', '1', null, '서울');
insert into tblMember values('bey2222', '배세', '1234', '1994-06-03', '9101@naver.com', '1', null, '부산');
insert into tblMember values('bey3333', '개세', '1234', '1994-07-03', '1121@naver.com', '1', null, '대구');
insert into tblMember values('bey4444', '훈이', '1234', '1994-08-03', '3141@naver.com', '1', null, '포항');


